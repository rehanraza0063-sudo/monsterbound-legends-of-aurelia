import { MOVES_BY_ID } from '../data/moves.js';
import { typeEffectiveness, effectivenessLabel } from '../data/types.js';
import GameState from './GameState.js';

const STAT_KEY_FOR_MOVE_STAT = { attack: 'attack', defense: 'defense', speed: 'speed', special: 'specialAttack' };

// BattleSystem is intentionally UI-agnostic: it emits a log of events that
// BattleScene renders/animates. This keeps battle logic testable and reusable
// (wild encounters, trainer battles, gym battles, rival battles all share it).
export default class BattleSystem {
  constructor({ playerMonster, enemyMonster, isWild, isTrainer, trainerData, isCapturable = true }) {
    this.player = playerMonster;
    this.enemy = enemyMonster;
    this.isWild = isWild;
    this.isTrainer = isTrainer;
    this.trainerData = trainerData || null;
    this.isCapturable = isCapturable && isWild;
    this.turnLog = [];
    this.battleOver = false;
    this.result = null; // 'win' | 'lose' | 'fled' | 'captured'
  }

  log(entry) { this.turnLog.push(entry); }

  getEffectiveStat(monster, statName) {
    const raw = monster[statName];
    const stageKey = statName === 'attack' ? 'attack' : statName === 'defense' ? 'defense'
      : statName === 'speed' ? 'speed' : statName === 'specialAttack' ? 'special' : null;
    return stageKey ? monster.statWithStage(raw, stageKey) : raw;
  }

  computeDamage(attacker, defender, move) {
    if (move.power === 0) return { damage: 0, crit: false, effectiveness: 1 };
    const isPhysical = move.category === 'physical';
    const atkStat = this.getEffectiveStat(attacker, isPhysical ? 'attack' : 'specialAttack');
    const defStat = this.getEffectiveStat(defender, isPhysical ? 'defense' : 'specialDefense');
    const level = attacker.level;
    const crit = Math.random() < 0.0625 ? 2 : 1;
    const effectiveness = typeEffectiveness(move.type || 'Flame', defender.species.type);
    const stab = attacker.species.type.includes(move.type) ? 1.5 : 1;
    const randomFactor = 0.85 + Math.random() * 0.15;
    let damage = Math.floor((((2 * level / 5 + 2) * move.power * (atkStat / Math.max(1, defStat))) / 50 + 2) * stab * effectiveness * crit * randomFactor);
    if (!move.type) damage = Math.floor(damage * effectiveness); // typeless generic moves treated neutral
    damage = Math.max(effectiveness === 0 ? 0 : 1, damage);
    return { damage, crit: crit === 2, effectiveness };
  }

  checkAccuracy(move) {
    return Math.random() * 100 < (move.accuracy ?? 100);
  }

  applyStatusStart(monster) {
    if (!monster.status) return { canAct: true };
    switch (monster.status) {
      case 'sleep':
        if (Math.random() < 0.33) { monster.status = null; this.log({ type: 'text', text: `${monster.name} woke up!` }); return { canAct: true }; }
        this.log({ type: 'text', text: `${monster.name} is fast asleep.` });
        return { canAct: false };
      case 'freeze':
        if (Math.random() < 0.2) { monster.status = null; this.log({ type: 'text', text: `${monster.name} thawed out!` }); return { canAct: true }; }
        this.log({ type: 'text', text: `${monster.name} is frozen solid!` });
        return { canAct: false };
      case 'shock':
        if (Math.random() < 0.25) { this.log({ type: 'text', text: `${monster.name} is paralyzed and can't move!` }); return { canAct: false }; }
        return { canAct: true };
      case 'confusion':
        if (Math.random() < 0.33) {
          const selfDmg = Math.max(1, Math.floor(monster.maxHp * 0.08));
          monster.currentHp = Math.max(0, monster.currentHp - selfDmg);
          this.log({ type: 'text', text: `${monster.name} hurt itself in confusion!` });
          return { canAct: false };
        }
        return { canAct: true };
      default:
        return { canAct: true };
    }
  }

  applyStatusEnd(monster) {
    if (monster.status === 'burn' || monster.status === 'poison') {
      const dmg = Math.max(1, Math.floor(monster.maxHp * 0.0625));
      monster.currentHp = Math.max(0, monster.currentHp - dmg);
      this.log({ type: 'text', text: `${monster.name} is hurt by its ${monster.status}!` });
    }
  }

  applyMoveEffect(user, target, move) {
    if (!move.effect) return;
    const { kind } = move.effect;
    if (kind === 'buff' || kind === 'debuff') {
      const who = move.effect.target === 'self' ? user : target;
      const statKey = STAT_KEY_FOR_MOVE_STAT[move.effect.stat] || move.effect.stat;
      const delta = kind === 'buff' ? move.effect.stages : -move.effect.stages;
      who.statStages[statKey] = Math.max(-6, Math.min(6, (who.statStages[statKey] || 0) + delta));
      this.log({ type: 'text', text: `${who.name}'s ${move.effect.stat} ${kind === 'buff' ? 'rose' : 'fell'}!` });
    } else if (kind === 'status') {
      const chance = move.effect.chance ?? 100;
      if (!target.status && Math.random() * 100 < chance) {
        target.status = move.effect.status;
        this.log({ type: 'text', text: `${target.name} was afflicted with ${move.effect.status}!` });
      }
    } else if (kind === 'heal') {
      const amount = Math.floor(user.maxHp * (move.effect.percent / 100));
      user.heal(amount);
      this.log({ type: 'text', text: `${user.name} recovered some HP!` });
    } else if (kind === 'protect') {
      user.protectFlag = true;
      this.log({ type: 'text', text: `${user.name} is protecting itself!` });
    } else if (kind === 'endure') {
      user.enduring = true;
    }
  }

  executeMove(user, target, moveEntry) {
    const move = MOVES_BY_ID[moveEntry.moveId];
    if (moveEntry.pp <= 0) {
      this.log({ type: 'text', text: `${user.name} has no PP left for that move! It struggled instead.` });
      const struggle = Object.values(MOVES_BY_ID).find(m => m.name === 'Struggle');
      moveEntry = { moveId: struggle.id, pp: 1 };
    }
    moveEntry.pp = Math.max(0, moveEntry.pp - 1);
    this.log({ type: 'move', user: user.name, move: move.name });

    if (target.protectFlag && move.power > 0) {
      this.log({ type: 'text', text: `${target.name} protected itself!` });
      target.protectFlag = false;
      return;
    }

    if (!this.checkAccuracy(move)) {
      this.log({ type: 'text', text: `${user.name}'s attack missed!` });
      return;
    }

    if (move.power > 0) {
      const hits = move.hits || 1;
      let totalDamage = 0;
      let lastEff = 1, anyCrit = false;
      for (let h = 0; h < hits; h++) {
        const { damage, crit, effectiveness } = this.computeDamage(user, target, move);
        totalDamage += damage;
        lastEff = effectiveness;
        anyCrit = anyCrit || crit;
      }
      if (target.enduring && totalDamage >= target.currentHp) {
        target.currentHp = 1;
        target.enduring = false;
        this.log({ type: 'text', text: `${target.name} endured the hit!` });
      } else {
        target.currentHp = Math.max(0, target.currentHp - totalDamage);
      }
      this.log({ type: 'damage', target: target.name, amount: totalDamage, crit: anyCrit, effectiveness: lastEff });
      const effText = effectivenessLabel(lastEff);
      if (effText) this.log({ type: 'text', text: effText });
      if (anyCrit) this.log({ type: 'text', text: 'A critical hit!' });
    }

    if (move.effect && (move.power === 0 || Math.random() < 0.4)) {
      this.applyMoveEffect(user, target, move);
    }
  }

  // Runs one full turn: playerMoveEntry OR playerAction ('run'|'switch'|'item'), enemy AI picks a move.
  runTurn(playerMoveEntry) {
    this.turnLog = [];
    if (this.battleOver) return this.turnLog;

    const enemyMoveEntry = this.pickEnemyMove();
    const playerFirst = this.getEffectiveStat(this.player, 'speed') >= this.getEffectiveStat(this.enemy, 'speed');
    const order = playerFirst
      ? [{ who: 'player', entry: playerMoveEntry }, { who: 'enemy', entry: enemyMoveEntry }]
      : [{ who: 'enemy', entry: enemyMoveEntry }, { who: 'player', entry: playerMoveEntry }];

    for (const turn of order) {
      const user = turn.who === 'player' ? this.player : this.enemy;
      const target = turn.who === 'player' ? this.enemy : this.player;
      if (user.isFainted || target.isFainted) continue;
      const statusCheck = this.applyStatusStart(user);
      if (!statusCheck.canAct) continue;
      this.executeMove(user, target, turn.entry);
      if (target.isFainted) {
        this.log({ type: 'faint', who: target.name });
        break;
      }
    }

    for (const m of [this.player, this.enemy]) {
      if (!m.isFainted) this.applyStatusEnd(m);
      if (m.isFainted) this.log({ type: 'faint', who: m.name });
    }

    if (this.enemy.isFainted) {
      this.result = 'win';
      this.battleOver = true;
      this.grantRewards();
    } else if (this.player.isFainted) {
      if (GameState.allFainted) {
        this.result = 'lose';
        this.battleOver = true;
      }
    }

    return this.turnLog;
  }

  pickEnemyMove() {
    const usable = this.enemy.moves.filter(m => m.pp > 0);
    const pool = usable.length ? usable : this.enemy.moves;
    return pool[Math.floor(Math.random() * pool.length)];
  }

  grantRewards() {
    const baseXp = Math.floor((this.enemy.species.base.hp + this.enemy.species.base.attack) * this.enemy.level / 7);
    const events = this.player.gainXp(baseXp);
    this.log({ type: 'xp', amount: baseXp, events });
    if (this.isTrainer && this.trainerData?.reward?.money) {
      GameState.money += this.trainerData.reward.money;
      this.log({ type: 'text', text: `You received $${this.trainerData.reward.money} for winning!` });
    }
  }

  attemptFlee() {
    if (this.isTrainer) return false;
    const chance = 0.5 + (this.getEffectiveStat(this.player, 'speed') - this.getEffectiveStat(this.enemy, 'speed')) / 256;
    const success = Math.random() < Math.max(0.1, Math.min(0.95, chance));
    if (success) { this.result = 'fled'; this.battleOver = true; }
    return success;
  }
}
