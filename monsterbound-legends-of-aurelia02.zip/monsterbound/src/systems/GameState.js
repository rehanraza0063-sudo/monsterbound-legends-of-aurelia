import Monster from '../entities/Monster.js';

// Single source of truth for all persistent player data. Systems (Save,
// Inventory, Quest, Battle, Capture, Evolution) all read/write through here.
class GameStateClass {
  constructor() {
    this.reset();
  }

  reset() {
    this.playerName = 'Trainer';
    this.money = 1500;
    this.currentMap = 'starting_village';
    this.position = { x: 10, y: 10 };
    this.facing = 'down';
    this.party = []; // array of Monster
    this.storage = []; // array of Monster (PC boxes, flattened)
    this.inventory = {}; // itemId -> qty
    this.badges = []; // badge ids
    this.flags = {}; // story/quest flags, e.g. { starter_chosen: true }
    this.quests = { active: [], completed: [], failed: [] };
    this.dex = { seen: new Set(), caught: new Set() };
    this.playTimeSeconds = 0;
    this.settings = { musicVolume: 0.3, sfxVolume: 0.5, textSpeed: 'normal', animations: true, fullscreen: false };
    this.debugMode = false;
    this.rivalDefeated = {};
  }

  addItem(itemId, qty = 1) {
    this.inventory[itemId] = (this.inventory[itemId] || 0) + qty;
  }

  removeItem(itemId, qty = 1) {
    if (!this.inventory[itemId]) return false;
    this.inventory[itemId] -= qty;
    if (this.inventory[itemId] <= 0) delete this.inventory[itemId];
    return true;
  }

  hasItem(itemId) { return (this.inventory[itemId] || 0) > 0; }

  addMonsterToPartyOrStorage(monster) {
    if (this.party.length < 6) {
      this.party.push(monster);
      return 'party';
    }
    this.storage.push(monster);
    return 'storage';
  }

  get firstHealthyMonster() {
    return this.party.find(m => !m.isFainted) || null;
  }

  get allFainted() {
    return this.party.length > 0 && this.party.every(m => m.isFainted);
  }

  markSeen(speciesId) { this.dex.seen.add(speciesId); }
  markCaught(speciesId) { this.dex.caught.add(speciesId); this.markSeen(speciesId); }

  serialize() {
    return {
      version: 1,
      playerName: this.playerName,
      money: this.money,
      currentMap: this.currentMap,
      position: this.position,
      facing: this.facing,
      party: this.party.map(m => m.serialize()),
      storage: this.storage.map(m => m.serialize()),
      inventory: this.inventory,
      badges: this.badges,
      flags: this.flags,
      quests: this.quests,
      dexSeen: [...this.dex.seen],
      dexCaught: [...this.dex.caught],
      playTimeSeconds: this.playTimeSeconds,
      settings: this.settings,
      rivalDefeated: this.rivalDefeated
    };
  }

  loadFrom(data) {
    this.reset();
    if (!data) return;
    try {
      this.playerName = data.playerName ?? this.playerName;
      this.money = data.money ?? this.money;
      this.currentMap = data.currentMap ?? this.currentMap;
      this.position = data.position ?? this.position;
      this.facing = data.facing ?? this.facing;
      this.party = (data.party || []).map(m => Monster.deserialize(m));
      this.storage = (data.storage || []).map(m => Monster.deserialize(m));
      this.inventory = data.inventory || {};
      this.badges = data.badges || [];
      this.flags = data.flags || {};
      this.quests = data.quests || { active: [], completed: [], failed: [] };
      this.dex.seen = new Set(data.dexSeen || []);
      this.dex.caught = new Set(data.dexCaught || []);
      this.playTimeSeconds = data.playTimeSeconds || 0;
      this.settings = { ...this.settings, ...(data.settings || {}) };
      this.rivalDefeated = data.rivalDefeated || {};
    } catch (e) {
      console.error('Save data appears corrupted, falling back to defaults for missing fields.', e);
    }
  }
}

const GameState = new GameStateClass();
export default GameState;
