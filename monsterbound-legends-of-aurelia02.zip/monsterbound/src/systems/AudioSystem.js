// All sound is synthesized with the Web Audio API so the project ships with
// zero binary audio assets, per spec section 34.
export default class AudioSystem {
  constructor() {
    this.ctx = null;
    this.musicGain = null;
    this.sfxVolume = 0.5;
    this.musicVolume = 0.3;
    this.currentMusicNodes = [];
  }

  _ensureCtx() {
    if (!this.ctx) {
      const AC = window.AudioContext || window.webkitAudioContext;
      this.ctx = new AC();
      this.musicGain = this.ctx.createGain();
      this.musicGain.gain.value = this.musicVolume;
      this.musicGain.connect(this.ctx.destination);
    }
    if (this.ctx.state === 'suspended') this.ctx.resume();
  }

  _tone(freq, duration, type = 'square', gainStart = 0.2, delay = 0) {
    this._ensureCtx();
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = type;
    osc.frequency.value = freq;
    gain.gain.value = gainStart * this.sfxVolume;
    osc.connect(gain);
    gain.connect(this.ctx.destination);
    const t0 = this.ctx.currentTime + delay;
    gain.gain.setValueAtTime(gainStart * this.sfxVolume, t0);
    gain.gain.exponentialRampToValueAtTime(0.001, t0 + duration);
    osc.start(t0);
    osc.stop(t0 + duration);
  }

  playMenu() { this._tone(440, 0.08, 'square', 0.15); }
  playInteract() { this._tone(660, 0.06, 'square', 0.15); }
  playDamage() { this._tone(120, 0.15, 'sawtooth', 0.25); }
  playCritical() {
    this._tone(180, 0.08, 'sawtooth', 0.3);
    this._tone(260, 0.1, 'sawtooth', 0.3, 0.08);
  }
  playCapture() {
    [330, 392, 494, 587].forEach((f, i) => this._tone(f, 0.12, 'square', 0.2, i * 0.12));
  }
  playVictory() {
    [523, 659, 784, 1046].forEach((f, i) => this._tone(f, 0.18, 'triangle', 0.22, i * 0.15));
  }
  playHeal() {
    [392, 523, 659].forEach((f, i) => this._tone(f, 0.15, 'sine', 0.2, i * 0.1));
  }
  playEvolution() {
    for (let i = 0; i < 8; i++) this._tone(300 + i * 60, 0.1, 'sine', 0.15, i * 0.09);
  }
  playFaint() { this._tone(200, 0.3, 'sawtooth', 0.2); this._tone(100, 0.4, 'sawtooth', 0.2, 0.15); }

  startFieldMusic() { this._startLoop([196, 220, 247, 220], 0.5); }
  startBattleMusic() { this._startLoop([146, 174, 196, 174, 220, 196], 0.28); }
  stopMusic() {
    this.currentMusicNodes.forEach(n => { try { n.stop(); } catch (e) { /* noop */ } });
    this.currentMusicNodes = [];
  }

  _startLoop(freqs, noteLen) {
    this.stopMusic();
    this._ensureCtx();
    let i = 0;
    const playNext = () => {
      if (!this.ctx) return;
      const f = freqs[i % freqs.length];
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.value = f;
      gain.gain.value = 0.12 * this.musicVolume;
      osc.connect(gain);
      gain.connect(this.musicGain);
      const t0 = this.ctx.currentTime;
      gain.gain.setValueAtTime(0.12 * this.musicVolume, t0);
      gain.gain.exponentialRampToValueAtTime(0.001, t0 + noteLen * 0.95);
      osc.start(t0);
      osc.stop(t0 + noteLen);
      this.currentMusicNodes.push(osc);
      i++;
      this._loopTimeout = setTimeout(playNext, noteLen * 1000);
    };
    playNext();
  }

  setVolumes(sfx, music) {
    this.sfxVolume = sfx;
    this.musicVolume = music;
    if (this.musicGain) this.musicGain.gain.value = music;
  }
}
