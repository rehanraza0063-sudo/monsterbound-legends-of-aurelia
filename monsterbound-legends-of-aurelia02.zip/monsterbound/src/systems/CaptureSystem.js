import { ITEMS_BY_ID } from '../data/items.js';

export default class CaptureSystem {
  // Returns { success: bool, shakes: 0-4 } - classic-style HP/rate/ball formula,
  // reskinned with original terminology (capsules instead of balls).
  static attempt(monster, capsuleId) {
    const capsule = ITEMS_BY_ID[capsuleId];
    if (!capsule) return { success: false, shakes: 0 };
    if (capsule.catchMultiplier >= 255) return { success: true, shakes: 4 };

    const maxHp = monster.maxHp;
    const curHp = Math.max(1, monster.currentHp);
    const baseRate = monster.species.captureRate;

    const statusBonus = ['sleep', 'freeze'].includes(monster.status) ? 2.5
      : ['poison', 'burn', 'shock', 'confusion', 'slow'].includes(monster.status) ? 1.5 : 1;

    const a = (((3 * maxHp - 2 * curHp) * baseRate * capsule.catchMultiplier) / (3 * maxHp)) * statusBonus;
    const catchValue = Math.min(255, a);

    let shakes = 0;
    for (let i = 0; i < 4; i++) {
      const roll = Math.random() * 255;
      if (roll < catchValue) shakes++;
      else break;
    }
    return { success: shakes >= 4, shakes };
  }
}
