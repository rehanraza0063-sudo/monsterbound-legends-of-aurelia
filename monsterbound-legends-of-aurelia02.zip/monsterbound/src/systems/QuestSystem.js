import GameState from './GameState.js';
import { QUESTS_BY_ID } from '../data/quests.js';
import InventorySystem from './InventorySystem.js';

export default class QuestSystem {
  static start(questId) {
    const q = QUESTS_BY_ID[questId];
    if (!q) return;
    if (GameState.quests.active.includes(questId) || GameState.quests.completed.includes(questId)) return;
    GameState.quests.active.push(questId);
  }

  static isActive(questId) { return GameState.quests.active.includes(questId); }
  static isCompleted(questId) { return GameState.quests.completed.includes(questId); }

  static complete(questId) {
    const q = QUESTS_BY_ID[questId];
    if (!q) return null;
    GameState.quests.active = GameState.quests.active.filter(id => id !== questId);
    if (!GameState.quests.completed.includes(questId)) GameState.quests.completed.push(questId);
    if (q.reward) {
      if (q.reward.money) GameState.money += q.reward.money;
      if (q.reward.items) q.reward.items.forEach(it => GameState.addItem(it.id, it.qty));
    }
    return q;
  }

  static fail(questId) {
    GameState.quests.active = GameState.quests.active.filter(id => id !== questId);
    if (!GameState.quests.failed.includes(questId)) GameState.quests.failed.push(questId);
  }

  static getActiveQuests() {
    return GameState.quests.active.map(id => QUESTS_BY_ID[id]).filter(Boolean);
  }

  static getCompletedQuests() {
    return GameState.quests.completed.map(id => QUESTS_BY_ID[id]).filter(Boolean);
  }
}
