import { getSpecies } from '../data/monsters.js';

export default class EvolutionSystem {
  static checkLevelEvolution(monster) {
    const species = monster.species;
    if (species.evolvesAtLevel && species.evolvesTo && monster.level >= species.evolvesAtLevel) {
      return species.evolvesTo;
    }
    return null;
  }

  static checkItemEvolution(monster, item) {
    const species = monster.species;
    if (!species.evolvesTo) return null;
    if (item.evolutionType && species.type.includes(item.evolutionType)) return species.evolvesTo;
    if (item.id === 'friendship_charm' && monster.friendship >= 80) return species.evolvesTo;
    return null;
  }

  // Applies the evolution in place (keeps uid/xp/moves; changes speciesId).
  static evolve(monster, toSpeciesId) {
    const newSpecies = getSpecies(toSpeciesId);
    if (!newSpecies) return false;
    monster.speciesId = toSpeciesId;
    return true;
  }
}
