import AudioSystem from './AudioSystem.js';

const instance = new AudioSystem();
export default instance;
