import GameState from './GameState.js';
import { ITEMS_BY_ID } from '../data/items.js';
import { MOVES_BY_ID } from '../data/moves.js';

export default class InventorySystem {
  static buy(itemId, qty = 1) {
    const item = ITEMS_BY_ID[itemId];
    if (!item) return { ok: false, message: 'Unknown item.' };
    const cost = item.price * qty;
    if (GameState.money < cost) return { ok: false, message: "You don't have enough money." };
    GameState.money -= cost;
    GameState.addItem(itemId, qty);
    return { ok: true, message: `Bought ${qty}x ${item.name}.` };
  }

  static sell(itemId, qty = 1) {
    const item = ITEMS_BY_ID[itemId];
    if (!item) return { ok: false, message: 'Unknown item.' };
    if (!GameState.hasItem(itemId) || (GameState.inventory[itemId] || 0) < qty) {
      return { ok: false, message: "You don't have that many." };
    }
    if (item.category === 'Key Items' || item.category === 'Quest Items') {
      return { ok: false, message: "You can't sell that." };
    }
    GameState.removeItem(itemId, qty);
    GameState.money += item.sellPrice * qty;
    return { ok: true, message: `Sold ${qty}x ${item.name}.` };
  }

  static use(itemId, monster) {
    const item = ITEMS_BY_ID[itemId];
    if (!item || !GameState.hasItem(itemId)) return { ok: false, message: "You don't have that item." };
    if (!item.effect) return { ok: false, message: "That can't be used right now." };

    switch (item.effect.kind) {
      case 'heal':
        if (monster.isFainted) return { ok: false, message: `${monster.name} has fainted and can't be healed by this.` };
        monster.heal(item.effect.amount);
        break;
      case 'cure_status':
        monster.status = null;
        break;
      case 'revive':
        if (!monster.isFainted) return { ok: false, message: `${monster.name} isn't fainted.` };
        monster.currentHp = Math.floor(monster.maxHp * (item.effect.percent / 100));
        break;
      case 'restore_pp':
        monster.moves.forEach(m => {
          const def = MOVES_BY_ID[m.moveId];
          m.pp = Math.min(def.maxPp, m.pp + item.effect.amount);
        });
        break;
      default:
        return { ok: false, message: "That item can't be used here." };
    }
    GameState.removeItem(itemId, 1);
    return { ok: true, message: `Used ${item.name} on ${monster.name}.` };
  }
}
