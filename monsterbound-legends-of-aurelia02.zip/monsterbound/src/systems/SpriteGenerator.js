import { TYPE_COLORS } from '../data/types.js';

// Generates original procedural textures at runtime using Phaser Graphics ->
// generateTexture. No binary art assets are shipped. This version pushes for
// a "polished stylized 2D RPG" look (layered shading, natural silhouettes,
// depth, texture) - the practical ceiling for code-drawn vector art. True
// photorealism would require hand-painted or AI-rendered raster assets
// loaded from files, which this sandbox can't produce - see README.
const GENERATED_KEYS = new Set();

function shade(color, amount) {
  const r = (color >> 16) & 0xff, g = (color >> 8) & 0xff, b = color & 0xff;
  const f = (c) => Math.max(0, Math.min(255, Math.round(c + (amount > 0 ? (255 - c) * amount : c * amount))));
  return (f(r) << 16) | (f(g) << 8) | f(b);
}

// deterministic pseudo-random noise so identical tiles get consistent but
// varied detail placement instead of looking copy-pasted
function hashNoise(x, y, salt = 0) {
  const n = Math.sin(x * 127.1 + y * 311.7 + salt * 74.7) * 43758.5453;
  return n - Math.floor(n);
}

export default class SpriteGenerator {
  constructor(scene) {
    this.scene = scene;
    this.generated = GENERATED_KEYS;
  }

  // -------------------- Ground / Tiles --------------------
  ensureTileTextures(legend) {
    for (const [ch, def] of Object.entries(legend)) {
      const key = `tile_${ch.charCodeAt(0)}`;
      if (this.generated.has(key)) continue;
      const g = this.scene.add.graphics();
      const base = def.color;
      const light = shade(base, 0.22);
      const dark = shade(base, -0.25);
      const isWater = base === 0x2e86ab || def.water;
      const isTree = base === 0x2e4d2e || ch === '#';

      if (isWater) {
        this._drawWaterTile(g, base, light, dark);
      } else if (isTree) {
        this._drawTreeTile(g, base, light, dark);
      } else if (def.encounter) {
        this._drawGrassTile(g, base, light, dark, true);
      } else if (ch === '.') {
        this._drawGrassTile(g, base, light, dark, false);
      } else if (ch === ',') {
        this._drawPathTile(g, base, light, dark);
      } else if (ch === 'B') {
        this._drawWallTile(g, base, light, dark);
      } else {
        g.fillStyle(base, 1);
        g.fillRect(0, 0, 32, 32);
      }

      if (def.heal) {
        g.fillStyle(0xffffff, 1);
        g.fillRoundedRect(5, 3, 22, 22, 5);
        g.lineStyle(1, 0xdddddd, 1);
        g.strokeRoundedRect(5, 3, 22, 22, 5);
        g.fillStyle(0xff5266, 1);
        g.fillRoundedRect(14, 7, 4, 14, 1);
        g.fillRoundedRect(9, 12, 14, 4, 1);
      }
      if (def.shop) {
        g.fillStyle(0x6d4c41, 1);
        g.fillRect(5, 13, 22, 15);
        g.fillStyle(0x4e342e, 1);
        g.fillTriangle(2, 13, 30, 13, 16, 2);
        g.fillStyle(0xa1887f, 1);
        g.fillTriangle(4, 12, 28, 12, 16, 4);
        g.fillStyle(0x3e2723, 1);
        g.fillRect(13, 19, 6, 9);
        g.fillStyle(0xffd54f, 0.9);
        g.fillCircle(17, 24, 0.8);
      }
      if (def.gym) {
        g.fillStyle(shade(base, -0.15), 1);
        g.fillRoundedRect(3, 7, 26, 22, 4);
        g.fillStyle(0xffffff, 1);
        g.fillTriangle(16, 3, 7, 15, 25, 15);
        g.lineStyle(1.5, 0xffd76e, 0.8);
        g.strokeTriangle(16, 3, 7, 15, 25, 15);
      }

      g.lineStyle(1, 0x000000, 0.08);
      g.strokeRect(0, 0, 32, 32);
      g.generateTexture(key, 32, 32);
      g.destroy();
      this.generated.add(key);
    }
  }

  _drawGrassTile(g, base, light, dark, tall) {
    // base with subtle per-pixel-cluster noise variation for an organic feel
    g.fillStyle(base, 1);
    g.fillRect(0, 0, 32, 32);
    for (let i = 0; i < 10; i++) {
      const n1 = hashNoise(i, 1); const n2 = hashNoise(i, 2); const n3 = hashNoise(i, 3);
      const x = n1 * 30, y = n2 * 30;
      g.fillStyle(n3 > 0.5 ? light : dark, 0.18);
      g.fillCircle(x, y, 2 + n3 * 3);
    }
    // blade tufts
    const bladeColor = tall ? shade(base, -0.3) : shade(base, -0.15);
    const count = tall ? 7 : 4;
    for (let i = 0; i < count; i++) {
      const n1 = hashNoise(i, 11), n2 = hashNoise(i, 12), n3 = hashNoise(i, 13);
      const bx = 3 + n1 * 24, by = 3 + n2 * 22, h = tall ? 10 + n3 * 6 : 5 + n3 * 3;
      g.fillStyle(bladeColor, 0.85);
      g.fillTriangle(bx, by + h, bx + 1.5, by, bx + 3, by + h);
      g.fillStyle(shade(bladeColor, 0.35), 0.6);
      g.fillTriangle(bx + 1, by + h, bx + 2, by + 2, bx + 2.5, by + h);
    }
  }

  _drawWaterTile(g, base, light, dark) {
    g.fillStyle(base, 1);
    g.fillRect(0, 0, 32, 32);
    g.fillStyle(dark, 0.25);
    g.fillRect(0, 20, 32, 12);
    for (let i = 0; i < 3; i++) {
      const y = 6 + i * 9;
      g.lineStyle(1.5, light, 0.55);
      g.beginPath();
      g.arc(6, y, 5, Math.PI, 0, false);
      g.arc(22, y, 5, Math.PI, 0, true);
      g.strokePath();
    }
    g.fillStyle(0xffffff, 0.15);
    g.fillEllipse(9, 8, 6, 2);
  }

  _drawTreeTile(g, base, light, dark) {
    // ground peeking through
    g.fillStyle(shade(base, 0.15), 1);
    g.fillRect(0, 0, 32, 32);
    // trunk with grain
    g.fillStyle(0x4e342e, 1);
    g.fillRect(13, 20, 6, 11);
    g.fillStyle(0x3e2723, 0.6);
    g.fillRect(15, 20, 1, 11);
    // layered canopy - three overlapping blobs, darkest at back
    g.fillStyle(dark, 1);
    g.fillCircle(16, 13, 13);
    g.fillStyle(base, 1);
    g.fillCircle(11, 10, 9);
    g.fillCircle(21, 11, 8);
    g.fillStyle(light, 0.7);
    g.fillCircle(11, 6, 4.5);
    g.fillStyle(0x000000, 0.15);
    g.fillEllipse(16, 27, 12, 3);
  }

  _drawPathTile(g, base, light, dark) {
    g.fillStyle(base, 1);
    g.fillRect(0, 0, 32, 32);
    for (let i = 0; i < 5; i++) {
      const n1 = hashNoise(i, 21), n2 = hashNoise(i, 22), n3 = hashNoise(i, 23);
      g.fillStyle(n3 > 0.5 ? light : dark, 0.3);
      g.fillEllipse(4 + n1 * 24, 4 + n2 * 24, 4 + n3 * 3, 2 + n3 * 2);
    }
    g.lineStyle(1, dark, 0.2);
    g.strokeRect(0, 0, 32, 32);
  }

  _drawWallTile(g, base, light, dark) {
    g.fillStyle(base, 1);
    g.fillRect(0, 0, 32, 32);
    g.lineStyle(1, dark, 0.5);
    for (let row = 0; row < 4; row++) {
      const offset = row % 2 === 0 ? 0 : 8;
      g.lineBetween(0, row * 8, 32, row * 8);
      for (let col = -1; col < 4; col++) g.lineBetween(offset + col * 16, row * 8, offset + col * 16, row * 8 + 8);
    }
    g.fillStyle(light, 0.15);
    g.fillRect(0, 0, 32, 4);
  }

  // Position-aware building parts so a block of 'B' tiles reads as an actual
  // house (roof cap on top, windows/door near the ground) instead of one
  // brick texture repeated everywhere.
  ensureBuildingPartTexture(part, baseColor) {
    const key = `bpart_${part}_${baseColor}`;
    if (this.generated.has(key)) return key;
    const g = this.scene.add.graphics();
    const light = shade(baseColor, 0.2);
    const dark = shade(baseColor, -0.28);
    const roofColor = shade(baseColor, -0.4);

    if (part === 'roof') {
      g.fillStyle(shade(roofColor, -0.15), 1);
      g.fillTriangle(0, 30, 32, 30, 16, 2);
      g.fillStyle(roofColor, 1);
      g.fillTriangle(3, 30, 29, 30, 16, 6);
      g.lineStyle(1, shade(roofColor, -0.3), 0.6);
      for (let i = 1; i < 5; i++) g.lineBetween(16 - i * 5, 30 - i * 5, 16 + i * 5, 30 - i * 5);
    } else if (part === 'window') {
      this._drawWallTile(g, baseColor, light, dark);
      g.fillStyle(0xbbdefb, 1);
      g.fillRoundedRect(8, 8, 16, 14, 2);
      g.lineStyle(1.5, 0x5d4037, 1);
      g.strokeRoundedRect(8, 8, 16, 14, 2);
      g.lineBetween(16, 8, 16, 22);
      g.lineBetween(8, 15, 24, 15);
      g.fillStyle(0xffffff, 0.4);
      g.fillRect(9, 9, 6, 5);
    } else if (part === 'door') {
      this._drawWallTile(g, baseColor, light, dark);
      g.fillStyle(0x3e2723, 1);
      g.fillRoundedRect(9, 10, 14, 22, 2);
      g.fillStyle(0xffd54f, 1);
      g.fillCircle(20, 21, 1.3);
      g.lineStyle(1, 0x2b1a15, 0.6);
      g.strokeRoundedRect(9, 10, 14, 22, 2);
    } else {
      this._drawWallTile(g, baseColor, light, dark);
    }

    g.lineStyle(1, 0x000000, 0.08);
    g.strokeRect(0, 0, 32, 32);
    g.generateTexture(key, 32, 32);
    g.destroy();
    this.generated.add(key);
    return key;
  }


  // -------------------- Buildings (rendered as multi-tile stamps) --------------------
  // Draws a full house texture (roof + walls + door + windows) sized to a
  // WxH tile footprint, more detailed than tiling a flat 'B' wall texture.
  ensureHouseTexture(key, tilesW, tilesH, roofColor, wallColor) {
    if (this.generated.has(key)) return key;
    const TS = 32;
    const w = tilesW * TS, h = tilesH * TS;
    const g = this.scene.add.graphics();
    const roofH = Math.floor(h * 0.4);
    const wallY = roofH - 6;
    const wallDark = shade(wallColor, -0.2);
    const wallLight = shade(wallColor, 0.15);
    const roofDark = shade(roofColor, -0.25);

    // wall
    g.fillStyle(wallColor, 1);
    g.fillRect(4, wallY, w - 8, h - wallY - 4);
    g.fillStyle(wallDark, 1);
    g.fillRect(4, h - 14, w - 8, 10); // base shadow band
    // wood plank seams
    g.lineStyle(1, wallDark, 0.35);
    for (let x = 12; x < w - 8; x += 14) g.lineBetween(x, wallY, x, h - 4);

    // roof (two-tone gable)
    g.fillStyle(roofDark, 1);
    g.fillTriangle(0, roofH, w, roofH, w / 2, 4);
    g.fillStyle(roofColor, 1);
    g.fillTriangle(6, roofH, w - 6, roofH, w / 2, 10);
    g.lineStyle(2, roofDark, 0.7);
    for (let i = 0; i < 6; i++) {
      const t = i / 6;
      g.lineBetween(w / 2 * (1 - t) + 3, roofH - t * (roofH - 10), w / 2 + w / 2 * t - 3, roofH - (1 - t) * 0);
    }

    // door
    const doorW = Math.min(22, w * 0.22), doorH = h - wallY - 10;
    const doorX = w / 2 - doorW / 2;
    g.fillStyle(0x3e2723, 1);
    g.fillRoundedRect(doorX, h - doorH - 4, doorW, doorH, 3);
    g.fillStyle(0xffd54f, 1);
    g.fillCircle(doorX + doorW - 5, h - doorH / 2, 1.4);

    // windows
    const winY = wallY + 10;
    g.fillStyle(0xbbdefb, 1);
    g.fillRoundedRect(w * 0.18, winY, 16, 14, 2);
    g.fillRoundedRect(w * 0.82 - 16, winY, 16, 14, 2);
    g.lineStyle(1.5, 0x5d4037, 1);
    g.strokeRoundedRect(w * 0.18, winY, 16, 14, 2);
    g.strokeRoundedRect(w * 0.82 - 16, winY, 16, 14, 2);
    g.lineBetween(w * 0.18 + 8, winY, w * 0.18 + 8, winY + 14);
    g.lineBetween(w * 0.82 - 8, winY, w * 0.82 - 8, winY + 14);
    g.fillStyle(wallLight, 0.4);
    g.fillRect(4, wallY, w - 8, 4);

    g.generateTexture(key, w, h);
    g.destroy();
    this.generated.add(key);
    return key;
  }

  // -------------------- Player / NPC --------------------
  ensurePersonTexture(key, color, accent = 0xffe0bd) {
    if (this.generated.has(key)) return key;
    const g = this.scene.add.graphics();
    const light = shade(color, 0.28);
    const dark = shade(color, -0.32);
    const skin = 0xf0c9a0;
    const skinShade = shade(skin, -0.15);
    const hair = 0x3b2a1a;

    g.fillStyle(0x000000, 0.25);
    g.fillEllipse(16, 29, 13, 4.5);

    // legs with shoes
    g.fillStyle(dark, 1);
    g.fillRoundedRect(10, 21, 5, 7, 1);
    g.fillRoundedRect(17, 21, 5, 7, 1);
    g.fillStyle(0x2b2b2b, 1);
    g.fillRoundedRect(9, 26, 6, 3, 1);
    g.fillRoundedRect(17, 26, 6, 3, 1);

    // torso with shading split (front lit, side shadow)
    g.fillStyle(dark, 1);
    g.fillRoundedRect(7, 11, 18, 13, 5);
    g.fillStyle(color, 1);
    g.fillRoundedRect(8, 11, 15, 13, 5);
    g.fillStyle(light, 1);
    g.fillRoundedRect(10, 13, 7, 9, 3);

    // arms with hands
    g.fillStyle(dark, 1);
    g.fillRoundedRect(3, 13, 4.5, 10, 2);
    g.fillRoundedRect(24.5, 13, 4.5, 10, 2);
    g.fillStyle(skinShade, 1);
    g.fillCircle(5, 23, 2.4);
    g.fillCircle(27, 23, 2.4);

    // neck + head
    g.fillStyle(skinShade, 1);
    g.fillRect(14, 9, 4, 3);
    g.fillStyle(skin, 1);
    g.fillCircle(16, 7, 7);
    g.fillStyle(0xffffff, 0.35);
    g.fillCircle(13.5, 5, 2);

    // hair
    g.fillStyle(hair, 1);
    g.beginPath();
    g.arc(16, 6, 7.5, Math.PI, Math.PI * 2, false);
    g.fillPath();
    g.fillRect(9, 4, 3, 5);
    g.fillRect(20, 4, 3, 5);

    // face
    g.fillStyle(0x2d2416, 1);
    g.fillCircle(13.2, 7.5, 1);
    g.fillCircle(18.8, 7.5, 1);
    g.lineStyle(1, 0xb56b5a, 0.7);
    g.lineBetween(15, 10, 17, 10);

    // accent scarf/bandana - reads class/role at a glance
    g.fillStyle(accent, 1);
    g.fillRoundedRect(9, 17, 14, 3.5, 1.5);
    g.fillStyle(shade(accent, -0.2), 1);
    g.fillTriangle(9, 20.5, 12, 20.5, 9, 25);

    g.lineStyle(1, 0x1a1a1a, 0.2);
    g.strokeRoundedRect(7, 11, 18, 13, 5);

    g.generateTexture(key, 32, 32);
    g.destroy();
    this.generated.add(key);
    return key;
  }

  // -------------------- Monsters --------------------
  ensureMonsterTexture(species) {
    const key = `mon_${species.id}`;
    if (this.generated.has(key)) return key;
    const type = species.type[0];
    const color = TYPE_COLORS[type] || 0x999999;
    const light = shade(color, 0.32);
    const dark = shade(color, -0.35);
    const variant = species.id % 4;
    const size = 96;
    const cx = size / 2, cy = size / 2 + 6;
    const g = this.scene.add.graphics();

    g.fillStyle(0x000000, 0.22);
    g.fillEllipse(cx, size - 10, 30, 8);

    const bodyShapes = () => {
      if (variant === 0) { g.fillCircle(cx, cy, 30); }
      else if (variant === 1) { g.fillRoundedRect(cx - 30, cy - 14, 60, 42, 18); g.fillCircle(cx, cy - 20, 18); }
      else if (variant === 2) { g.fillTriangle(cx, cy - 34, cx - 30, cy + 26, cx + 30, cy + 26); }
      else { g.fillRoundedRect(cx - 28, cy - 28, 56, 56, 22); }
    };

    g.fillStyle(dark, 1);
    bodyShapes();

    // lighter belly patch, shifted for a natural shading gradient look
    g.fillStyle(shade(color, 0.08), 1);
    g.save();
    g.translateCanvas(cx, cy + 8);
    g.scale(0.6, 0.55);
    g.translateCanvas(-cx, -cy - 8);
    bodyShapes();
    g.restore();

    g.fillStyle(light, 0.4);
    g.fillEllipse(cx - 11, cy - 17, 20, 11);

    // subtle texture speckle for organic feel
    for (let i = 0; i < 6; i++) {
      const n1 = hashNoise(species.id, i), n2 = hashNoise(species.id, i + 50);
      g.fillStyle(dark, 0.25);
      g.fillCircle(cx - 20 + n1 * 40, cy - 5 + n2 * 30, 2 + n1 * 2);
    }

    this._drawTypeKit(g, type, cx, cy, color, dark, light);

    const eyeY = variant === 2 ? cy - 4 : cy - 2;
    g.fillStyle(0xffffff, 1);
    g.fillCircle(cx - 13, eyeY, 7.5);
    g.fillCircle(cx + 13, eyeY, 7.5);
    g.fillStyle(0x161616, 1);
    g.fillCircle(cx - 13, eyeY, 4.2);
    g.fillCircle(cx + 13, eyeY, 4.2);
    g.fillStyle(0xffffff, 0.95);
    g.fillCircle(cx - 15, eyeY - 2.2, 1.7);
    g.fillCircle(cx + 11, eyeY - 2.2, 1.7);
    // simple mouth for character
    g.lineStyle(1.5, shade(dark, -0.3), 0.8);
    g.beginPath();
    g.arc(cx, eyeY + 10, 5, 0.2, Math.PI - 0.2, false);
    g.strokePath();

    g.lineStyle(2.5, shade(dark, -0.25), 0.9);
    bodyShapes();

    if (species.rarity !== 'common') {
      const ringColor = species.rarity === 'legendary' ? 0xffd76e : species.rarity === 'very rare' ? 0xff6ec7 : 0xffffff;
      const rings = species.rarity === 'legendary' ? 3 : species.rarity === 'very rare' ? 2 : 1;
      for (let i = 0; i < rings; i++) {
        g.lineStyle(2, ringColor, 0.5 - i * 0.13);
        g.strokeCircle(cx, cy, 42 + i * 5);
      }
    }

    g.generateTexture(key, size, size);
    g.destroy();
    this.generated.add(key);
    return key;
  }

  _drawTypeKit(g, type, cx, cy, color, dark, light) {
    switch (type) {
      case 'Flame':
        g.fillStyle(0xffb74d, 1);
        g.fillTriangle(cx - 7, cy - 34, cx, cy - 50, cx + 7, cy - 34);
        g.fillStyle(0xff6f00, 1);
        g.fillTriangle(cx - 3.5, cy - 34, cx, cy - 43, cx + 3.5, cy - 34);
        g.fillStyle(0xffe082, 0.9);
        g.fillTriangle(cx - 1.5, cy - 34, cx, cy - 39, cx + 1.5, cy - 34);
        break;
      case 'Aqua':
        g.fillStyle(light, 1);
        g.fillTriangle(cx - 32, cy - 4, cx - 46, cy - 12, cx - 32, cy - 18);
        g.fillTriangle(cx + 32, cy - 4, cx + 46, cy - 12, cx + 32, cy - 18);
        g.lineStyle(1.5, dark, 0.5);
        g.strokeTriangle(cx - 32, cy - 4, cx - 46, cy - 12, cx - 32, cy - 18);
        break;
      case 'Nature':
        g.fillStyle(0x81c784, 1);
        g.fillEllipse(cx - 20, cy - 28, 15, 9);
        g.fillEllipse(cx + 20, cy - 28, 15, 9);
        g.lineStyle(1, 0x4a7c4e, 0.6);
        g.lineBetween(cx - 20, cy - 33, cx - 20, cy - 23);
        g.lineBetween(cx + 20, cy - 33, cx + 20, cy - 23);
        break;
      case 'Storm':
        g.fillStyle(0xfff176, 1);
        g.fillTriangle(cx, cy - 32, cx - 7, cy - 14, cx + 2, cy - 14);
        g.fillTriangle(cx + 2, cy - 14, cx - 5, cy + 4, cx + 7, cy - 8);
        break;
      case 'Stone':
        g.fillStyle(dark, 1);
        g.fillTriangle(cx - 11, cy - 30, cx - 4, cy - 44, cx + 2, cy - 30);
        g.fillTriangle(cx + 4, cy - 30, cx + 11, cy - 42, cx + 17, cy - 30);
        g.lineStyle(1, shade(dark, -0.3), 0.6);
        g.strokeTriangle(cx - 11, cy - 30, cx - 4, cy - 44, cx + 2, cy - 30);
        break;
      case 'Frost':
        g.lineStyle(2, 0xe1f5fe, 0.95);
        for (let a = 0; a < 6; a++) {
          const ang = (Math.PI / 3) * a;
          g.lineBetween(cx, cy - 34, cx + Math.cos(ang) * 11, cy - 34 + Math.sin(ang) * 11);
        }
        g.fillStyle(0xe1f5fe, 0.8);
        g.fillCircle(cx, cy - 34, 3);
        break;
      case 'Shadow':
        g.fillStyle(0x1a0033, 0.92);
        g.fillTriangle(cx - 28, cy + 10, cx - 42, cy + 4, cx - 30, cy + 24);
        g.fillTriangle(cx + 28, cy + 10, cx + 42, cy + 4, cx + 30, cy + 24);
        break;
      case 'Light':
        g.lineStyle(2, 0xfff9c4, 0.95);
        g.strokeCircle(cx, cy - 32, 11);
        g.fillStyle(0xfff9c4, 0.55);
        g.fillCircle(cx, cy - 32, 5.5);
        for (let a = 0; a < 8; a++) {
          const ang = (Math.PI / 4) * a;
          g.lineBetween(cx + Math.cos(ang) * 12, cy - 32 + Math.sin(ang) * 12, cx + Math.cos(ang) * 16, cy - 32 + Math.sin(ang) * 16);
        }
        break;
      case 'Metal':
        g.fillStyle(0xcfd8dc, 1);
        g.fillRoundedRect(cx - 3.5, cy - 42, 7, 16, 2);
        g.fillCircle(cx, cy - 42, 4.5);
        g.lineStyle(1, 0x78909c, 0.7);
        g.strokeRoundedRect(cx - 3.5, cy - 42, 7, 16, 2);
        break;
      case 'Wind':
        g.lineStyle(2.5, 0xe0f7fa, 0.85);
        g.beginPath(); g.arc(cx, cy - 8, 36, Math.PI * 1.15, Math.PI * 1.85, false); g.strokePath();
        g.lineStyle(1.5, 0xe0f7fa, 0.6);
        g.beginPath(); g.arc(cx, cy - 8, 30, Math.PI * 1.2, Math.PI * 1.7, false); g.strokePath();
        break;
      case 'Mystic':
        g.fillStyle(0xf3e5f5, 0.85);
        g.fillCircle(cx - 22, cy - 22, 4.5);
        g.fillCircle(cx + 22, cy - 18, 3.5);
        g.fillCircle(cx, cy - 38, 4);
        g.lineStyle(1, 0xf3e5f5, 0.4);
        g.lineBetween(cx - 22, cy - 22, cx, cy - 38);
        g.lineBetween(cx + 22, cy - 18, cx, cy - 38);
        break;
      case 'Earth':
        g.fillStyle(dark, 1);
        g.fillRoundedRect(cx - 25, cy + 16, 11, 10, 2);
        g.fillRoundedRect(cx + 14, cy + 16, 11, 10, 2);
        g.lineStyle(1, shade(dark, -0.3), 0.5);
        g.strokeRoundedRect(cx - 25, cy + 16, 11, 10, 2);
        break;
      default:
        break;
    }
  }

  ensureSolidTexture(key, color, w = 32, h = 32) {
    if (this.generated.has(key)) return key;
    const g = this.scene.add.graphics();
    g.fillStyle(color, 1);
    g.fillRect(0, 0, w, h);
    g.generateTexture(key, w, h);
    g.destroy();
    this.generated.add(key);
    return key;
  }
}
