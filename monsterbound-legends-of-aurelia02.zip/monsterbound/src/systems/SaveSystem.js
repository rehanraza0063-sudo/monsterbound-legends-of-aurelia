import GameState from './GameState.js';

const SAVE_KEY = 'monsterbound_save_v1';

export default class SaveSystem {
  static save() {
    try {
      const data = GameState.serialize();
      localStorage.setItem(SAVE_KEY, JSON.stringify(data));
      return true;
    } catch (e) {
      console.error('Failed to save game:', e);
      return false;
    }
  }

  static hasSave() {
    try {
      return !!localStorage.getItem(SAVE_KEY);
    } catch (e) {
      return false;
    }
  }

  static load() {
    try {
      const raw = localStorage.getItem(SAVE_KEY);
      if (!raw) return false;
      const data = JSON.parse(raw);
      GameState.loadFrom(data);
      return true;
    } catch (e) {
      console.error('Save data is corrupted or unreadable. Starting a new game instead.', e);
      GameState.reset();
      return false;
    }
  }

  static deleteSave() {
    try {
      localStorage.removeItem(SAVE_KEY);
      return true;
    } catch (e) {
      return false;
    }
  }

  static newGame() {
    GameState.reset();
  }
}
