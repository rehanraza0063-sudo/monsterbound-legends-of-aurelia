export default class PreloadScene extends Phaser.Scene {
  constructor() { super('PreloadScene'); }

  preload() {
    const { width, height } = this.scale;
    this.add.rectangle(0, 0, width, height, 0x0b0d17).setOrigin(0);
    this.add.text(width / 2, height / 2 - 10, 'MONSTERBOUND', { fontFamily: 'monospace', fontSize: '32px', color: '#ffd76e' }).setOrigin(0.5);
    this.add.text(width / 2, height / 2 + 24, 'Preparing Aurelia...', { fontFamily: 'monospace', fontSize: '14px', color: '#ffffff' }).setOrigin(0.5);
  }

  create() {
    // All art/audio is generated procedurally at runtime (see SpriteGenerator
    // and AudioSystem) so there is nothing further to preload from disk.
    this.time.delayedCall(300, () => this.scene.start('TitleScene'));
  }
}
