import GameState from '../systems/GameState.js';
import BattleSystem from '../systems/BattleSystem.js';
import CaptureSystem from '../systems/CaptureSystem.js';
import EvolutionSystem from '../systems/EvolutionSystem.js';
import SpriteGenerator from '../systems/SpriteGenerator.js';
import AudioSystem from '../systems/AudioSystemInstance.js';
import InventorySystem from '../systems/InventorySystem.js';
import { MOVES_BY_ID } from '../data/moves.js';
import { ITEMS_BY_ID } from '../data/items.js';
import { getSpecies } from '../data/monsters.js';
import Monster from '../entities/Monster.js';

const MENU_STATES = { ROOT: 'root', FIGHT: 'fight', MONSTERS: 'monsters', BAG: 'bag' };

export default class BattleScene extends Phaser.Scene {
  constructor() { super('BattleScene'); }

  init(data) {
    this.isWild = data.isWild;
    this.isTrainer = data.isTrainer;
    this.trainerName = data.trainerName;
    this.enemyParty = data.enemyParty;
    this.enemyIndex = 0;
    this.playerMonster = GameState.firstHealthyMonster;
    this.locked = false;
  }

  create() {
    const { width, height } = this.scale;
    this.spriteGen = new SpriteGenerator(this);
    this._drawBattleBackground();
    AudioSystem.startBattleMusic();

    this.enemyMonster = this.enemyParty[this.enemyIndex];
    this.battle = new BattleSystem({
      playerMonster: this.playerMonster,
      enemyMonster: this.enemyMonster,
      isWild: this.isWild,
      isTrainer: this.isTrainer,
      trainerData: this.trainerName ? { name: this.trainerName } : null
    });

    this._buildSprites();
    this._buildHudBoxes();
    this._buildMenu();
    this.menuState = MENU_STATES.ROOT;
    this.locked = false;

    if (this.trainerName) {
      this._pushMessage(`${this.trainerName} wants to battle!`);
    } else {
      this._pushMessage(`A wild ${this.enemyMonster.name} appeared!`);
    }
  }

  _drawBattleBackground() {
    const { width, height } = this.scale;
    const g = this.add.graphics();
    // sky gradient (band-stepped, since Phaser Graphics has no true gradient fill)
    const skyTop = 0x5fa8e0, skyBottom = 0xcdeaff;
    const bands = 20;
    for (let i = 0; i < bands; i++) {
      const t = i / bands;
      const r = Math.round(((skyTop >> 16) & 0xff) * (1 - t) + ((skyBottom >> 16) & 0xff) * t);
      const gg = Math.round(((skyTop >> 8) & 0xff) * (1 - t) + ((skyBottom >> 8) & 0xff) * t);
      const b = Math.round((skyTop & 0xff) * (1 - t) + (skyBottom & 0xff) * t);
      g.fillStyle((r << 16) | (gg << 8) | b, 1);
      g.fillRect(0, (height * 0.58 / bands) * i, width, height * 0.58 / bands + 1);
    }
    // distant hills
    g.fillStyle(0x9ccf7a, 0.6);
    g.fillEllipse(width * 0.15, height * 0.56, width * 0.5, 60);
    g.fillEllipse(width * 0.75, height * 0.58, width * 0.6, 70);
    // ground
    g.fillStyle(0x6b8e4e, 1);
    g.fillRect(0, height * 0.55, width, height * 0.45);
    g.fillStyle(0x7fa85c, 1);
    g.fillEllipse(width * 0.72, height * 0.66, width * 0.4, 40);
    g.fillEllipse(width * 0.26, height * 0.85, width * 0.5, 55);
    // soft clouds
    g.fillStyle(0xffffff, 0.85);
    [[0.15, 0.12], [0.4, 0.08], [0.68, 0.15]].forEach(([px, py]) => {
      const cx = width * px, cy = height * py;
      g.fillEllipse(cx, cy, 46, 16);
      g.fillEllipse(cx + 20, cy - 6, 30, 14);
      g.fillEllipse(cx - 18, cy - 4, 26, 12);
    });
  }

  _buildSprites() {
    const enemyKey = this.spriteGen.ensureMonsterTexture(this.enemyMonster.species);
    const playerKey = this.spriteGen.ensureMonsterTexture(this.playerMonster.species);
    this.enemySprite = this.add.image(this.scale.width * 0.72, this.scale.height * 0.32, enemyKey).setScale(1.1);
    this.playerSprite = this.add.image(this.scale.width * 0.26, this.scale.height * 0.62, playerKey).setScale(1.4).setFlipX(true);
  }

  _buildHudBoxes() {
    const w = this.scale.width;
    this.enemyHud = this.add.container(20, 20);
    const enemyBg = this.add.rectangle(0, 0, 260, 60, 0xffffff, 0.9).setOrigin(0).setStrokeStyle(2, 0x000000);
    this.enemyNameText = this.add.text(10, 6, '', { fontFamily: 'monospace', fontSize: '14px', color: '#000000', fontStyle: 'bold' });
    this.enemyHpBarBg = this.add.rectangle(10, 30, 180, 10, 0x333333).setOrigin(0);
    this.enemyHpBar = this.add.rectangle(10, 30, 180, 10, 0x4caf50).setOrigin(0);
    this.enemyHpText = this.add.text(196, 26, '', { fontFamily: 'monospace', fontSize: '11px', color: '#000000' });
    this.enemyHud.add([enemyBg, this.enemyNameText, this.enemyHpBarBg, this.enemyHpBar, this.enemyHpText]);

    this.playerHud = this.add.container(w - 280, this.scale.height * 0.42);
    const playerBg = this.add.rectangle(0, 0, 260, 70, 0xffffff, 0.9).setOrigin(0).setStrokeStyle(2, 0x000000);
    this.playerNameText = this.add.text(10, 6, '', { fontFamily: 'monospace', fontSize: '14px', color: '#000000', fontStyle: 'bold' });
    this.playerHpBarBg = this.add.rectangle(10, 30, 180, 10, 0x333333).setOrigin(0);
    this.playerHpBar = this.add.rectangle(10, 30, 180, 10, 0x4caf50).setOrigin(0);
    this.playerHpText = this.add.text(10, 46, '', { fontFamily: 'monospace', fontSize: '12px', color: '#000000' });
    this.playerHud.add([playerBg, this.playerNameText, this.playerHpBarBg, this.playerHpBar, this.playerHpText]);

    this._refreshHud();

    const boxH = 110;
    this.msgBg = this.add.rectangle(0, this.scale.height - boxH, this.scale.width, boxH, 0x0b0d17, 0.95).setOrigin(0).setStrokeStyle(2, 0xffffff);
    this.msgText = this.add.text(20, this.scale.height - boxH + 12, '', { fontFamily: 'monospace', fontSize: '15px', color: '#ffffff', wordWrap: { width: this.scale.width * 0.55 } });
  }

  _refreshHud() {
    this.enemyNameText.setText(`${this.enemyMonster.name}  Lv${this.enemyMonster.level}`);
    const eRatio = Math.max(0, this.enemyMonster.currentHp / this.enemyMonster.maxHp);
    this.enemyHpBar.width = 180 * eRatio;
    this.enemyHpBar.fillColor = eRatio > 0.5 ? 0x4caf50 : eRatio > 0.2 ? 0xffb300 : 0xe53935;
    this.enemyHpText.setText(`${this.enemyMonster.currentHp}/${this.enemyMonster.maxHp}`);

    this.playerNameText.setText(`${this.playerMonster.name}  Lv${this.playerMonster.level}`);
    const pRatio = Math.max(0, this.playerMonster.currentHp / this.playerMonster.maxHp);
    this.playerHpBar.width = 180 * pRatio;
    this.playerHpBar.fillColor = pRatio > 0.5 ? 0x4caf50 : pRatio > 0.2 ? 0xffb300 : 0xe53935;
    this.playerHpText.setText(`HP ${this.playerMonster.currentHp}/${this.playerMonster.maxHp}`);
  }

  _buildMenu() {
    const w = this.scale.width, h = this.scale.height, boxH = 110;
    this.menuContainer = this.add.container(this.scale.width * 0.58, h - boxH);
    this.menuBg = this.add.rectangle(0, 0, w * 0.42, boxH, 0x1a1a2e, 0.95).setOrigin(0).setStrokeStyle(2, 0xffffff);
    this.menuContainer.add(this.menuBg);
    this.menuItemTexts = [];
    this.menuIndex = 0;
    this._renderRootMenu();

    this.input.keyboard.on('keydown-UP', () => this._navMenu(-1));
    this.input.keyboard.on('keydown-DOWN', () => this._navMenu(1));
    this.input.keyboard.on('keydown-LEFT', () => this._navMenu(-1));
    this.input.keyboard.on('keydown-RIGHT', () => this._navMenu(1));
    this.input.keyboard.on('keydown-Z', () => this._confirmMenu());
    this.input.keyboard.on('keydown-X', () => this._backMenu());
  }

  _clearMenuTexts() {
    this.menuItemTexts.forEach(t => t.destroy());
    this.menuItemTexts = [];
  }

  _renderRootMenu() {
    this._clearMenuTexts();
    this.menuState = MENU_STATES.ROOT;
    const labels = ['FIGHT', 'MONSTERS', 'BAG', this.isWild ? 'CAPTURE' : 'RUN'];
    this._renderList(labels, 2);
  }

  _renderList(labels, cols) {
    this.menuIndex = 0;
    this.currentLabels = labels;
    labels.forEach((label, i) => {
      const col = i % cols;
      const row = Math.floor(i / cols);
      const t = this.add.text(20 + col * 150, 16 + row * 30, label, { fontFamily: 'monospace', fontSize: '16px', color: '#ffffff' });
      this.menuContainer.add(t);
      this.menuItemTexts.push(t);
    });
    this._highlightMenu();
  }

  _highlightMenu() {
    this.menuItemTexts.forEach((t, i) => t.setColor(i === this.menuIndex ? '#ffd76e' : '#ffffff'));
  }

  _navMenu(dir) {
    if (this.locked || !this.menuItemTexts.length) return;
    this.menuIndex = (this.menuIndex + dir + this.menuItemTexts.length) % this.menuItemTexts.length;
    this._highlightMenu();
  }

  _backMenu() {
    if (this.menuState !== MENU_STATES.ROOT) this._renderRootMenu();
  }

  _confirmMenu() {
    if (this.locked) return;
    AudioSystem.playMenu();
    if (this.menuState === MENU_STATES.ROOT) {
      const label = this.currentLabels[this.menuIndex];
      if (label === 'FIGHT') this._renderFightMenu();
      else if (label === 'MONSTERS') this._renderMonstersMenu();
      else if (label === 'BAG') this._renderBagMenu();
      else if (label === 'CAPTURE') this._renderCaptureMenu();
      else if (label === 'RUN') this._tryRun();
    } else if (this.menuState === MENU_STATES.FIGHT) {
      this._selectMove(this.menuIndex);
    } else if (this.menuState === MENU_STATES.MONSTERS) {
      this._selectSwitch(this.menuIndex);
    } else if (this.menuState === MENU_STATES.BAG) {
      this._selectBagOrCapsule(this.menuIndex);
    }
  }

  _renderFightMenu() {
    this._clearMenuTexts();
    this.menuState = MENU_STATES.FIGHT;
    const labels = this.playerMonster.moves.map(m => {
      const def = MOVES_BY_ID[m.moveId];
      return `${def.name} (${m.pp}/${def.maxPp})`;
    });
    this._renderList(labels, 2);
  }

  _renderMonstersMenu() {
    this._clearMenuTexts();
    this.menuState = MENU_STATES.MONSTERS;
    const labels = GameState.party.map(m => `${m.name} Lv${m.level} ${m.isFainted ? '(fainted)' : `${m.currentHp}/${m.maxHp}`}`);
    this._renderList(labels, 1);
  }

  _renderBagMenu() {
    this._clearMenuTexts();
    this.menuState = MENU_STATES.BAG;
    this.bagContext = 'items';
    const usable = Object.keys(GameState.inventory).filter(id => ITEMS_BY_ID[id]?.effect);
    const labels = usable.length ? usable.map(id => `${ITEMS_BY_ID[id].name} x${GameState.inventory[id]}`) : ['(no usable items)'];
    this._bagIds = usable;
    this._renderList(labels, 1);
  }

  _renderCaptureMenu() {
    this._clearMenuTexts();
    this.menuState = MENU_STATES.BAG;
    this.bagContext = 'capsules';
    const capsules = Object.keys(GameState.inventory).filter(id => ITEMS_BY_ID[id]?.catchMultiplier);
    const labels = capsules.length ? capsules.map(id => `${ITEMS_BY_ID[id].name} x${GameState.inventory[id]}`) : ['(no capsules)'];
    this._bagIds = capsules;
    this._renderList(labels, 1);
  }

  _selectBagOrCapsule(index) {
    if (!this._bagIds || !this._bagIds.length) { this._renderRootMenu(); return; }
    const itemId = this._bagIds[index];
    if (this.bagContext === 'capsules') {
      this._doCapture(itemId);
    } else {
      const res = InventorySystem.use(itemId, this.playerMonster);
      this._pushMessage(res.message);
      this._refreshHud();
      this._endPlayerTurnAfterItem();
    }
  }

  _selectMove(index) {
    const moveEntry = this.playerMonster.moves[index];
    if (moveEntry.pp <= 0) { this._pushMessage('No PP left for that move!'); return; }
    this._runBattleTurn(moveEntry);
  }

  _selectSwitch(index) {
    const chosen = GameState.party[index];
    if (!chosen || chosen.isFainted || chosen === this.playerMonster) { this._renderRootMenu(); return; }
    this.playerMonster = chosen;
    this.battle.player = chosen;
    this.playerSprite.setTexture(this.spriteGen.ensureMonsterTexture(chosen.species));
    this._refreshHud();
    this._pushMessage(`Go, ${chosen.name}!`);
    this._renderRootMenu();
  }

  _tryRun() {
    const success = this.battle.attemptFlee();
    if (success) {
      this._pushMessage('Got away safely!');
      this.time.delayedCall(900, () => this._endBattle('fled'));
    } else {
      this._pushMessage("Couldn't get away!");
      this._enemyOnlyRetaliation();
    }
  }

  _doCapture(capsuleId) {
    GameState.removeItem(capsuleId, 1);
    const result = CaptureSystem.attempt(this.enemyMonster, capsuleId);
    AudioSystem.playCapture();
    this._pushMessage(`You threw a ${ITEMS_BY_ID[capsuleId].name}...`);
    this.time.delayedCall(900, () => {
      if (result.success) {
        this._pushMessage(`Gotcha! ${this.enemyMonster.name} was caught!`);
        const caught = new Monster(this.enemyMonster.speciesId, this.enemyMonster.level, {
          currentHp: this.enemyMonster.currentHp, caughtWith: capsuleId
        });
        GameState.markCaught(caught.speciesId);
        const where = GameState.addMonsterToPartyOrStorage(caught);
        this.time.delayedCall(1000, () => {
          this._pushMessage(where === 'party' ? 'Added to your party!' : 'Sent to storage (party full).');
          this.time.delayedCall(900, () => this._endBattle('captured'));
        });
      } else {
        this._pushMessage(`Oh no! It broke free! (${result.shakes} shake${result.shakes === 1 ? '' : 's'})`);
        this.time.delayedCall(900, () => this._enemyOnlyRetaliation());
      }
    });
  }

  _enemyOnlyRetaliation() {
    this.locked = true;
    const enemyMove = this.battle.pickEnemyMove();
    this.battle.turnLog = [];
    this.battle.executeMove(this.enemyMonster, this.playerMonster, enemyMove);
    this._playLog(this.battle.turnLog, () => {
      this._refreshHud();
      this._checkFaintsAndContinue();
    });
  }

  _endPlayerTurnAfterItem() {
    this.locked = true;
    this.time.delayedCall(600, () => this._enemyOnlyRetaliation());
  }

  _runBattleTurn(moveEntry) {
    this.locked = true;
    const log = this.battle.runTurn(moveEntry);
    this._playLog(log, () => {
      this._refreshHud();
      this._checkFaintsAndContinue();
    });
  }

  _playLog(log, onDone) {
    let i = 0;
    const step = () => {
      if (i >= log.length) { onDone(); return; }
      const entry = log[i++];
      if (entry.type === 'move') {
        this._pushMessage(`${entry.user} used ${entry.move}!`);
      } else if (entry.type === 'damage') {
        if (entry.crit) AudioSystem.playCritical(); else AudioSystem.playDamage();
        this._flashDamage(entry.target === this.enemyMonster.name ? this.enemySprite : this.playerSprite);
        this._refreshHud();
      } else if (entry.type === 'text') {
        this._pushMessage(entry.text);
      } else if (entry.type === 'faint') {
        AudioSystem.playFaint();
        this._pushMessage(`${entry.who} fainted!`);
      } else if (entry.type === 'xp') {
        this._pushMessage(`${this.playerMonster.name} gained ${entry.amount} XP!`);
        (entry.events || []).forEach(ev => {
          if (ev.type === 'levelup') this._pushMessage(`${this.playerMonster.name} grew to level ${ev.level}!`);
          if (ev.type === 'learnmove') this._pushMessage(`${this.playerMonster.name} learned ${MOVES_BY_ID[ev.moveId].name}!`);
          if (ev.type === 'evolve_ready') this._queuedEvolution = ev.toId;
        });
      }
      this.time.delayedCall(700, step);
    };
    step();
  }

  _flashDamage(sprite) {
    this.tweens.add({ targets: sprite, alpha: 0.2, duration: 80, yoyo: true, repeat: 2 });
  }

  _checkFaintsAndContinue() {
    this.locked = false;
    if (this.enemyMonster.isFainted) {
      this.enemyIndex++;
      if (this.isTrainer && this.enemyIndex < this.enemyParty.length) {
        this.enemyMonster = this.enemyParty[this.enemyIndex];
        this.battle.enemy = this.enemyMonster;
        this.enemySprite.setTexture(this.spriteGen.ensureMonsterTexture(this.enemyMonster.species));
        this._refreshHud();
        this._pushMessage(`${this.trainerName} sent out ${this.enemyMonster.name}!`);
        this._renderRootMenu();
        return;
      }
      AudioSystem.playVictory();
      this._maybeEvolveThenEnd('win');
      return;
    }
    if (this.playerMonster.isFainted) {
      const next = GameState.firstHealthyMonster;
      if (next) {
        this._pushMessage(`${this.playerMonster.name} fainted! Choose your next monster.`);
        this.time.delayedCall(600, () => this._renderMonstersMenu());
        return;
      }
      this._pushMessage('You have no monsters left able to battle...');
      this.time.delayedCall(1000, () => this._endBattle('lose'));
      return;
    }
    this._renderRootMenu();
  }

  _maybeEvolveThenEnd(result) {
    const toId = EvolutionSystem.checkLevelEvolution(this.playerMonster);
    if (toId) {
      const fromName = this.playerMonster.name;
      AudioSystem.playEvolution();
      this._pushMessage(`${fromName} is evolving!`);
      this.time.delayedCall(1200, () => {
        EvolutionSystem.evolve(this.playerMonster, toId);
        this._pushMessage(`${fromName} evolved into ${getSpecies(toId).name}!`);
        this.time.delayedCall(1200, () => this._endBattle(result));
      });
    } else {
      this.time.delayedCall(600, () => this._endBattle(result));
    }
  }

  _pushMessage(text) { this.msgText.setText(text); }

  _endBattle(result) {
    AudioSystem.stopMusic();
    this.scene.stop();
    this.scene.get('WorldScene').events.emit('battleEnded', { result });
  }
}
