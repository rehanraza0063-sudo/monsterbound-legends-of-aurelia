import GameState from '../systems/GameState.js';
import SaveSystem from '../systems/SaveSystem.js';
import QuestSystem from '../systems/QuestSystem.js';
import AudioSystem from '../systems/AudioSystemInstance.js';
import SpriteGenerator from '../systems/SpriteGenerator.js';
import Player from '../entities/Player.js';
import NPC from '../entities/NPC.js';
import DialogueBox from '../ui/DialogueBox.js';
import { MAPS, TILE_SIZE } from '../data/maps.js';
import { MONSTERS, STARTER_IDS, getSpecies } from '../data/monsters.js';
import { GYM_LEADERS, RIVAL, generateGenericTrainer } from '../data/trainers.js';
import { ITEMS_BY_ID } from '../data/items.js';
import Monster from '../entities/Monster.js';

export default class WorldScene extends Phaser.Scene {
  constructor() { super('WorldScene'); }

  init(data) { this.justStarted = data?.justStarted ?? false; }

  create() {
    this.spriteGen = new SpriteGenerator(this);
    this.mapLayer = this.add.container(0, 0);
    this.entityLayer = this.add.container(0, 0);
    this.dialogue = new DialogueBox(this);
    this.debugText = this.add.text(6, 6, '', { fontFamily: 'monospace', fontSize: '11px', color: '#00ff00' }).setDepth(2000).setVisible(false);
    this.locationBanner = this.add.text(this.scale.width / 2, 20, '', { fontFamily: 'monospace', fontSize: '16px', color: '#ffffff', backgroundColor: '#00000099', padding: { x: 10, y: 4 } }).setOrigin(0.5).setDepth(900);

    this.cursors = this.input.keyboard.createCursorKeys();
    this.keys = this.input.keyboard.addKeys('W,A,S,D,Z,X,SPACE,F1');
    this.input.keyboard.on('keydown-F1', () => this.toggleDebug());

    this.loadMap(GameState.currentMap, GameState.position.x, GameState.position.y);
    AudioSystem.startFieldMusic();

    this.events.on('resume', () => {
      // returning from battle/menu
    });

    if (this.justStarted) {
      this.time.delayedCall(300, () => this.startIntro());
    }

    this.events.on('battleEnded', this.onBattleEnded, this);
  }

  startIntro() {
    this.dialogue.showLines([
      'Welcome to the continent of Aurelia.',
      'This land is home to countless original monster species, and a young trainer\'s journey always begins with a single companion.'
    ], 'Narrator');
  }

  toggleDebug() {
    GameState.debugMode = !GameState.debugMode;
    this.debugText.setVisible(GameState.debugMode);
  }

  // -------------------- Map loading --------------------
  loadMap(mapId, spawnX, spawnY) {
    this.mapLayer.removeAll(true);
    this.entityLayer.removeAll(true);
    const mapData = MAPS[mapId];
    this.currentMapData = mapData;
    GameState.currentMap = mapId;
    this.spriteGen.ensureTileTextures(this._legend());
    this.locationBanner.setText(mapData.name);
    this.locationBanner.setAlpha(1);
    this.tweens.add({ targets: this.locationBanner, alpha: 0, delay: 1400, duration: 600 });

    this.tileGrid = mapData.layout;
    const buildingWallColor = 0x7a5c3e;
    for (let y = 0; y < this.tileGrid.length; y++) {
      for (let x = 0; x < this.tileGrid[y].length; x++) {
        const ch = this.tileGrid[y][x];
        let key;
        if (ch === 'B') {
          const above = y > 0 ? this.tileGrid[y - 1][x] : null;
          const below = y < this.tileGrid.length - 1 ? this.tileGrid[y + 1][x] : null;
          const isTopRow = above !== 'B';
          const isGroundRow = below !== 'B'; // next tile down is not part of the building
          if (isTopRow) {
            key = this.spriteGen.ensureBuildingPartTexture('roof', buildingWallColor);
          } else if (isGroundRow) {
            // alternate door/window along the ground row using x-parity so
            // a building reads as "one door, several windows" not identical tiles
            const part = (x % 3 === 0) ? 'door' : 'window';
            key = this.spriteGen.ensureBuildingPartTexture(part, buildingWallColor);
          } else {
            key = this.spriteGen.ensureBuildingPartTexture('wall', buildingWallColor);
          }
        } else {
          key = `tile_${ch.charCodeAt(0)}`;
        }
        const img = this.add.image(x * TILE_SIZE + TILE_SIZE / 2, y * TILE_SIZE + TILE_SIZE / 2, key);
        this.mapLayer.add(img);
      }
    }


    this.npcs = (mapData.npcs || []).map(def => {
      const texKey = `npc_${def.sprite || 'npc_generic'}`;
      this.spriteGen.ensurePersonTexture(texKey, def.isRival ? 0x3949ab : (def.trainerClass ? 0xc62828 : 0x546e7a));
      const npc = new NPC(this, def, texKey);
      this.entityLayer.add(npc.sprite);
      return npc;
    });

    this.spriteGen.ensurePersonTexture('player_tex', 0xffd76e);
    const px = spawnX ?? mapData.spawn.x;
    const py = spawnY ?? mapData.spawn.y;
    this.player = new Player(this, px, py, 'player_tex');
    this.entityLayer.add(this.player.sprite);

    const w = this.tileGrid[0].length * TILE_SIZE;
    const h = this.tileGrid.length * TILE_SIZE;
    this.cameras.main.setBounds(0, 0, w, h);
    this.cameras.main.startFollow(this.player.sprite, true, 0.15, 0.15);
    this.map = {
      isWalkable: (x, y) => this._isWalkable(x, y)
    };
  }

  _legend() {
    return {
      '.': { solid: false, color: 0x4caf50 }, ':': { solid: false, color: 0x2e7d32, encounter: true },
      ',': { solid: false, color: 0xd7ccc8 }, '#': { solid: true, color: 0x2e4d2e },
      '~': { solid: true, color: 0x2e86ab }, B: { solid: true, color: 0x7a5c3e },
      D: { solid: false, color: 0xc9a876, warpTile: true }, H: { solid: false, color: 0xff8fa3, heal: true },
      S: { solid: false, color: 0xffd54f, shop: true }, G: { solid: false, color: 0x9575cd, gym: 'gym1' }
    };
  }

  _tileAt(x, y) {
    if (y < 0 || y >= this.tileGrid.length || x < 0 || x >= this.tileGrid[0].length) return '#';
    return this.tileGrid[y][x];
  }

  _isWalkable(x, y) {
    const ch = this._tileAt(x, y);
    const legend = this._legend();
    if (!legend[ch]) return false;
    if (legend[ch].solid) return false;
    if (this.npcs?.some(n => n.gridX === x && n.gridY === y)) return false;
    return true;
  }

  // -------------------- Update loop --------------------
  update() {
    this.debugText.setVisible(GameState.debugMode);
    if (GameState.debugMode) {
      this.debugText.setText([
        `DEBUG MODE (F1)`,
        `Map: ${GameState.currentMap} Pos: ${this.player?.gridX},${this.player?.gridY}`,
        `Party: ${GameState.party.length} Money: $${GameState.money}`,
        `[1] Heal party  [2] +500 money  [3] Toggle encounters`
      ].join('\n'));
      this._debugHotkeys();
    }

    if (this.dialogue.isActive) {
      if (this.dialogue.choiceTexts.length) {
        if (Phaser.Input.Keyboard.JustDown(this.cursors.up) || Phaser.Input.Keyboard.JustDown(this.keys.W)) this.dialogue.moveChoice(-1);
        if (Phaser.Input.Keyboard.JustDown(this.cursors.down) || Phaser.Input.Keyboard.JustDown(this.keys.S)) this.dialogue.moveChoice(1);
        if (Phaser.Input.Keyboard.JustDown(this.keys.Z)) this.dialogue.confirmChoice();
      } else if (Phaser.Input.Keyboard.JustDown(this.keys.Z)) {
        this.dialogue.advance();
      }
      return;
    }
    if (!this.player || this.player.moving) return;

    if (Phaser.Input.Keyboard.JustDown(this.keys.X)) {
      this.openMenu();
      return;
    }

    const running = this.keys.SPACE.isDown;
    let dx = 0, dy = 0;
    if (this.cursors.left.isDown || this.keys.A.isDown) dx = -1;
    else if (this.cursors.right.isDown || this.keys.D.isDown) dx = 1;
    else if (this.cursors.up.isDown || this.keys.W.isDown) dy = -1;
    else if (this.cursors.down.isDown || this.keys.S.isDown) dy = 1;

    if (dx !== 0 || dy !== 0) {
      const moved = this.player.tryMove(dx, dy, running, this.map, (x, y) => this.onArrive(x, y));
      if (!moved) this._faceOnly(dx, dy);
    }

    if (Phaser.Input.Keyboard.JustDown(this.keys.Z)) {
      this.tryInteract();
    }
  }

  _debugHotkeys() {
    if (Phaser.Input.Keyboard.JustDown(this.input.keyboard.addKey('ONE'))) {
      GameState.party.forEach(m => m.fullHeal());
    }
    if (Phaser.Input.Keyboard.JustDown(this.input.keyboard.addKey('TWO'))) {
      GameState.money += 500;
    }
    if (Phaser.Input.Keyboard.JustDown(this.input.keyboard.addKey('THREE'))) {
      this.debugNoEncounters = !this.debugNoEncounters;
    }
  }

  _faceOnly(dx, dy) {
    if (dx !== 0) this.player.facing = dx > 0 ? 'right' : 'left';
    if (dy !== 0) this.player.facing = dy > 0 ? 'down' : 'up';
  }

  onArrive(x, y) {
    const ch = this._tileAt(x, y);
    const mapData = this.currentMapData;

    // Warps
    const warp = (mapData.warps || []).find(w => w.x === x && w.y === y);
    if (warp) {
      this.loadMap(warp.toMap, warp.toX, warp.toY);
      GameState.position = { x: warp.toX, y: warp.toY };
      return;
    }
    GameState.position = { x, y };

    // Encounters
    const legend = this._legend();
    if (legend[ch]?.encounter && !this.debugNoEncounters && mapData.encounterTable?.length) {
      const rate = mapData.encounterRate ?? 0.12;
      if (Math.random() < rate) {
        this.startWildEncounter(mapData.encounterTable);
      }
    }
  }

  // -------------------- Interaction --------------------
  tryInteract() {
    const { x, y } = this.player.facingTile();
    const npc = this.npcs.find(n => n.gridX === x && n.gridY === y);
    if (npc) { this.interactWithNpc(npc); return; }

    const ch = this._tileAt(x, y);
    const legend = this._legend();
    if (legend[ch]?.heal) { this.useHealingCenter(); return; }
    if (legend[ch]?.shop) { this.openShop(); return; }
    if (legend[ch]?.gym) { this.enterGym(legend[ch].gym); return; }
    AudioSystem.playInteract();
  }

  interactWithNpc(npc) {
    AudioSystem.playInteract();
    const def = npc.def;

    if (def.givesStarterChoice && !GameState.flags.starter_chosen) {
      this.dialogue.showLines(def.dialogue, def.name, () => this.offerStarterChoice());
      return;
    }
    if (def.isRival && def.battleOnTalk && !GameState.rivalDefeated[def.battleOnTalk]) {
      this.dialogue.showLines(def.dialogue, def.name, () => this.startRivalBattle(def.battleOnTalk));
      return;
    }
    if (def.trainerClass && def.trainerBattle && !npc.talkedTo) {
      this.dialogue.showLines(def.dialogue, def.name, () => this.startGenericTrainerBattle(npc));
      return;
    }
    if (def.questId && !QuestSystem.isActive(def.questId) && !QuestSystem.isCompleted(def.questId)) {
      this.dialogue.showLines(def.dialogue, def.name, () => {
        QuestSystem.start(def.questId);
      });
      return;
    }
    if (def.questId && QuestSystem.isActive(def.questId)) {
      this.tryQuestTurnIn(def);
      return;
    }
    this.dialogue.showLines(def.dialogue, def.name);
  }

  tryQuestTurnIn(def) {
    // Simple item-based quest turn-in for relic-style quests.
    if (def.questId === 'side_01_whisperwood_relic') {
      if (GameState.hasItem('whisperwood_relic')) {
        GameState.removeItem('whisperwood_relic', 1);
        const q = QuestSystem.complete(def.questId);
        this.dialogue.showLines([`You found it! Thank you so much.`, `Here, take this as thanks.`], def.name);
      } else {
        this.dialogue.showLines(['Please, if you find that relic in the forest, bring it to me.'], def.name);
      }
      return;
    }
    if (def.questId === 'main_04_eclipse_whisperwood') {
      this.dialogue.showLines(def.dialogue, def.name, () => this.startGenericTrainerBattle(this.npcs.find(n => n.def.id === def.id)));
      return;
    }
    this.dialogue.showLines(def.dialogue, def.name);
  }

  offerStarterChoice() {
    const names = STARTER_IDS.map(id => getSpecies(id).name);
    this.dialogue.showChoice('Which monster will you choose?', names, (index) => {
      const speciesId = STARTER_IDS[index];
      const starter = new Monster(speciesId, 5);
      GameState.addMonsterToPartyOrStorage(starter);
      GameState.markCaught(speciesId);
      GameState.flags.starter_chosen = true;
      QuestSystem.start('main_01_choose_starter');
      QuestSystem.complete('main_01_choose_starter');
      QuestSystem.start('main_02_reach_lumina');
      this.dialogue.showLines([`${getSpecies(speciesId).name} joined your party!`, 'Your journey across Aurelia begins now.'], 'Professor Aria');
    });
  }

  useHealingCenter() {
    AudioSystem.playHeal();
    GameState.party.forEach(m => m.fullHeal());
    this.dialogue.showLines(['Your monsters have been fully healed!', 'Good luck out there.'], 'Nurse');
    this.time.delayedCall(50, () => SaveSystem.save());
  }

  openShop() {
    const stock = ['potion', 'super_potion', 'full_heal', 'revive', 'basic_capsule', 'advanced_capsule'];
    const lines = stock.map(id => `${ITEMS_BY_ID[id].name} - $${ITEMS_BY_ID[id].price}`);
    this.dialogue.showChoice('What would you like to buy? (Z to confirm, X to leave)', [...lines, 'Leave'], (index) => {
      if (index === stock.length) return;
      const itemId = stock[index];
      const item = ITEMS_BY_ID[itemId];
      if (GameState.money >= item.price) {
        GameState.money -= item.price;
        GameState.addItem(itemId, 1);
        this.dialogue.showLines([`Bought 1x ${item.name}.`], 'Shopkeeper', () => this.openShop());
      } else {
        this.dialogue.showLines(["You don't have enough money."], 'Shopkeeper', () => this.openShop());
      }
    });
  }

  enterGym(gymId) {
    const gym = GYM_LEADERS.find(g => g.id === gymId);
    if (!gym) return;
    if (GameState.badges.includes(gym.badge)) {
      this.dialogue.showLines(['Thanks again for the great battle!'], gym.name);
      return;
    }
    if (!GameState.firstHealthyMonster) {
      this.dialogue.showLines(['Heal your monsters before challenging me!'], gym.name);
      return;
    }
    this.dialogue.showLines([gym.dialogueIntro], gym.name, () => {
      const party = gym.party.map(p => {
        const species = MONSTERS.find(m => m.name === p.speciesName);
        return new Monster(species.id, p.level);
      });
      this.startTrainerBattleSequence(party, gym.name, {
        onWin: () => {
          if (!GameState.badges.includes(gym.badge)) GameState.badges.push(gym.badge);
          this.dialogue.showLines([gym.dialogueDefeat], gym.name, () => {
            GameState.money += gym.reward?.money || 0;
            SaveSystem.save();
          });
        }
      });
    });
  }

  startGenericTrainerBattle(npc) {
    if (!npc || npc.talkedTo) return;
    const def = npc.def;
    const { levelRange, speciesPool } = def.trainerBattle;
    const trainer = generateGenericTrainer(def.trainerClass, levelRange, speciesPool, def.name);
    const party = trainer.party.map(p => {
      const species = MONSTERS.find(m => m.name === p.speciesName);
      return new Monster(species.id, p.level);
    });
    this.startTrainerBattleSequence(party, def.name, {
      trainerData: trainer,
      onWin: () => {
        npc.talkedTo = true;
        if (def.questId) QuestSystem.complete(def.questId);
      }
    });
  }

  startRivalBattle(encounterKey) {
    const encounter = RIVAL.encounters.find((e, i) => `rival_${i + 1}` === encounterKey);
    const idx = RIVAL.encounters.findIndex((e, i) => `rival_${i + 1}` === encounterKey);
    const level = encounter ? encounter.level : 5;
    const myStarter = GameState.party[0];
    const rivalSpecies = myStarter ? getSpecies(myStarter.speciesId).id : STARTER_IDS[0];
    // Rival always picks a different starter line than the player for variety.
    const rivalStarterId = STARTER_IDS.find(id => id !== rivalSpecies) || STARTER_IDS[0];
    const rivalMon = new Monster(rivalStarterId, level);
    this.startTrainerBattleSequence([rivalMon], RIVAL.name, {
      onWin: () => { GameState.rivalDefeated[encounterKey] = true; },
      onLose: () => { /* rival battles are non-fatal story beats either way */ }
    });
  }

  startTrainerBattleSequence(enemyParty, trainerName, hooks) {
    if (!GameState.firstHealthyMonster) {
      this.dialogue.showLines(["You need a healthy monster to battle!"], 'System');
      return;
    }
    this.pendingBattleHooks = hooks;
    this.scene.launch('BattleScene', {
      isWild: false, isTrainer: true, trainerName, enemyParty,
      playerParty: GameState.party
    });
    this.scene.pause();
  }

  startWildEncounter(table) {
    const totalWeight = table.reduce((s, e) => s + e.weight, 0);
    let roll = Math.random() * totalWeight;
    let chosen = table[0];
    for (const e of table) {
      if (roll < e.weight) { chosen = e; break; }
      roll -= e.weight;
    }
    const species = MONSTERS.find(m => m.name === chosen.speciesName);
    const [minL, maxL] = chosen.levelRange;
    const level = minL + Math.floor(Math.random() * (maxL - minL + 1));
    const wildMon = new Monster(species.id, level);
    GameState.markSeen(species.id);

    if (!GameState.firstHealthyMonster) return; // can't battle, silently skip

    this.scene.launch('BattleScene', {
      isWild: true, isTrainer: false, enemyParty: [wildMon], playerParty: GameState.party
    });
    this.scene.pause();
  }

  onBattleEnded(payload) {
    this.scene.resume();
    if (payload.result === 'win' && this.pendingBattleHooks?.onWin) this.pendingBattleHooks.onWin();
    if (payload.result === 'lose') {
      GameState.party.forEach(m => { if (m.isFainted) m.currentHp = Math.floor(m.maxHp * 0.5); });
      GameState.money = Math.max(0, GameState.money - 100);
      this.dialogue.showLines(['You rushed back after your monsters fainted...', 'Lost a little money along the way.'], 'System');
      this.loadMap('starting_village', 10, 10);
    }
    this.pendingBattleHooks = null;
    SaveSystem.save();
  }

  openMenu() {
    this.scene.launch('MenuScene');
    this.scene.pause();
  }
}
