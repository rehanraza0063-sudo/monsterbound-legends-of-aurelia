export default class BootScene extends Phaser.Scene {
  constructor() { super('BootScene'); }

  create() {
    this.scale.refresh();
    this.scene.start('PreloadScene');
  }
}
