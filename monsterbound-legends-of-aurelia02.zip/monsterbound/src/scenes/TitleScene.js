import SaveSystem from '../systems/SaveSystem.js';
import GameState from '../systems/GameState.js';
import AudioSystemSingleton from '../systems/AudioSystemInstance.js';

export default class TitleScene extends Phaser.Scene {
  constructor() { super('TitleScene'); }

  create() {
    const { width, height } = this.scale;
    this.add.rectangle(0, 0, width, height, 0x0b0d17).setOrigin(0);
    this.add.text(width / 2, height / 2 - 120, 'MONSTERBOUND', { fontFamily: 'monospace', fontSize: '44px', color: '#ffd76e', fontStyle: 'bold' }).setOrigin(0.5);
    this.add.text(width / 2, height / 2 - 76, 'Legends of Aurelia', { fontFamily: 'monospace', fontSize: '20px', color: '#ffffff' }).setOrigin(0.5);

    const options = ['New Game'];
    if (SaveSystem.hasSave()) options.push('Continue');
    options.push('Options');

    this.selected = 0;
    this.optionTexts = options.map((label, i) =>
      this.add.text(width / 2, height / 2 + 10 + i * 36, label, {
        fontFamily: 'monospace', fontSize: '22px', color: '#ffffff'
      }).setOrigin(0.5).setInteractive({ useHandCursor: true })
        .on('pointerdown', () => this.choose(i, options))
        .on('pointerover', () => { this.selected = i; this.refresh(); })
    );
    this.options = options;
    this.refresh();

    this.input.keyboard.on('keydown-UP', () => { this.selected = (this.selected - 1 + options.length) % options.length; this.refresh(); });
    this.input.keyboard.on('keydown-DOWN', () => { this.selected = (this.selected + 1) % options.length; this.refresh(); });
    this.input.keyboard.on('keydown-Z', () => this.choose(this.selected, options));
    this.input.keyboard.on('keydown-ENTER', () => this.choose(this.selected, options));

    this.add.text(width / 2, height - 30, 'An original monster-collecting RPG - inspired by, not copied from, any existing franchise.', {
      fontFamily: 'monospace', fontSize: '11px', color: '#666666'
    }).setOrigin(0.5);
  }

  refresh() {
    this.optionTexts.forEach((t, i) => t.setColor(i === this.selected ? '#ffd76e' : '#ffffff'));
  }

  choose(index, options) {
    AudioSystemSingleton.playMenu();
    const label = options[index];
    if (label === 'New Game') {
      SaveSystem.newGame();
      this.scene.start('WorldScene', { justStarted: true });
    } else if (label === 'Continue') {
      SaveSystem.load();
      this.scene.start('WorldScene', { justStarted: false });
    } else if (label === 'Options') {
      this.scene.launch('MenuScene', { tab: 'Options', fromTitle: true });
      this.scene.pause();
    }
  }
}
