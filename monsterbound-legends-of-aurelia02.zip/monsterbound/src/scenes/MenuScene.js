import GameState from '../systems/GameState.js';
import SaveSystem from '../systems/SaveSystem.js';
import QuestSystem from '../systems/QuestSystem.js';
import AudioSystem from '../systems/AudioSystemInstance.js';
import { MONSTERS, MONSTER_COUNT, getSpecies } from '../data/monsters.js';
import { ITEMS_BY_ID } from '../data/items.js';
import { MAP_IDS, MAPS } from '../data/maps.js';
import { AURELIA_BADGES } from '../data/items.js';

const TABS = ['MONSTERS', 'BAG', 'ARCHIVE', 'QUESTS', 'MAP', 'TRAINER', 'SAVE', 'OPTIONS'];

export default class MenuScene extends Phaser.Scene {
  constructor() { super('MenuScene'); }

  init(data) {
    this.fromTitle = data?.fromTitle || false;
    this.initialTab = data?.tab || 'MONSTERS';
  }

  create() {
    const { width, height } = this.scale;
    this.add.rectangle(0, 0, width, height, 0x0b0d17, 0.94).setOrigin(0);
    this.tabIndex = Math.max(0, TABS.indexOf(this.initialTab));
    this.tabTexts = TABS.map((tab, i) =>
      this.add.text(20 + i * 92, 16, tab, { fontFamily: 'monospace', fontSize: '13px', color: '#ffffff' })
    );
    this.contentContainer = this.add.container(20, 56);
    this._renderTab();

    this.input.keyboard.on('keydown-LEFT', () => this._changeTab(-1));
    this.input.keyboard.on('keydown-RIGHT', () => this._changeTab(1));
    this.input.keyboard.on('keydown-X', () => this._close());
    this.input.keyboard.on('keydown-ESC', () => this._close());
  }

  _changeTab(dir) {
    this.tabIndex = (this.tabIndex + dir + TABS.length) % TABS.length;
    AudioSystem.playMenu();
    this._renderTab();
  }

  _highlightTabs() {
    this.tabTexts.forEach((t, i) => t.setColor(i === this.tabIndex ? '#ffd76e' : '#ffffff'));
  }

  _clearContent() {
    this.contentContainer.removeAll(true);
  }

  _renderTab() {
    this._highlightTabs();
    this._clearContent();
    const tab = TABS[this.tabIndex];
    if (tab === 'MONSTERS') this._renderMonsters();
    else if (tab === 'BAG') this._renderBag();
    else if (tab === 'ARCHIVE') this._renderArchive();
    else if (tab === 'QUESTS') this._renderQuests();
    else if (tab === 'MAP') this._renderMap();
    else if (tab === 'TRAINER') this._renderTrainer();
    else if (tab === 'SAVE') this._renderSave();
    else if (tab === 'OPTIONS') this._renderOptions();
  }

  _text(x, y, str, style = {}) {
    const t = this.add.text(x, y, str, { fontFamily: 'monospace', fontSize: '14px', color: '#ffffff', ...style });
    this.contentContainer.add(t);
    return t;
  }

  _renderMonsters() {
    this._text(0, 0, 'YOUR PARTY', { color: '#ffd76e', fontSize: '16px' });
    if (!GameState.party.length) { this._text(0, 30, 'No monsters yet.'); return; }
    GameState.party.forEach((m, i) => {
      const y = 30 + i * 40;
      this._text(0, y, `${m.name}  Lv${m.level}  ${m.species.type.join('/')}`);
      this._text(0, y + 18, `HP ${m.currentHp}/${m.maxHp}  ${m.status ? '[' + m.status + ']' : ''}`, { fontSize: '12px', color: '#aaaaaa' });
    });
  }

  _renderBag() {
    this._text(0, 0, 'BAG', { color: '#ffd76e', fontSize: '16px' });
    const entries = Object.entries(GameState.inventory);
    if (!entries.length) { this._text(0, 30, 'Your bag is empty.'); return; }
    entries.forEach(([id, qty], i) => {
      const item = ITEMS_BY_ID[id];
      this._text(0, 30 + i * 22, `${item ? item.name : id} x${qty}  (${item?.category || ''})`);
    });
  }

  _renderArchive() {
    this._text(0, 0, `MONSTER ARCHIVE  (${GameState.dex.caught.size}/${MONSTER_COUNT} caught, ${GameState.dex.seen.size} seen)`, { color: '#ffd76e', fontSize: '16px' });
    const seenList = MONSTERS.filter(m => GameState.dex.seen.has(m.id)).slice(0, 18);
    seenList.forEach((m, i) => {
      const col = Math.floor(i / 9);
      const row = i % 9;
      const caught = GameState.dex.caught.has(m.id);
      this._text(col * 300, 30 + row * 20, `#${m.id} ${m.name} (${m.type.join('/')}) ${caught ? '[caught]' : '[seen]'}`, { fontSize: '12px' });
    });
    if (!seenList.length) this._text(0, 30, 'No monsters discovered yet. Get exploring!');
  }

  _renderQuests() {
    this._text(0, 0, 'QUEST LOG', { color: '#ffd76e', fontSize: '16px' });
    const active = QuestSystem.getActiveQuests();
    this._text(0, 26, 'Active:', { color: '#ffd76e', fontSize: '13px' });
    active.forEach((q, i) => this._text(10, 46 + i * 34, `${q.name} [${q.chapter}]\n${q.steps[0]}`, { fontSize: '12px', color: '#dddddd' }));
    const completedY = 46 + active.length * 34 + 20;
    this._text(0, completedY, 'Completed:', { color: '#4caf50', fontSize: '13px' });
    const completed = QuestSystem.getCompletedQuests();
    completed.forEach((q, i) => this._text(10, completedY + 20 + i * 16, q.name, { fontSize: '11px', color: '#888888' }));
  }

  _renderMap() {
    this._text(0, 0, 'WORLD MAP', { color: '#ffd76e', fontSize: '16px' });
    this._text(0, 26, `Currently in: ${MAPS[GameState.currentMap]?.name || GameState.currentMap}`, { fontSize: '13px' });
    MAP_IDS.forEach((id, i) => {
      const discovered = id === GameState.currentMap || GameState.flags[`discovered_${id}`];
      this._text(0, 56 + i * 20, discovered ? `- ${MAPS[id].name}` : '- ??? (undiscovered)', { fontSize: '13px', color: discovered ? '#ffffff' : '#555555' });
    });
  }

  _renderTrainer() {
    this._text(0, 0, 'TRAINER CARD', { color: '#ffd76e', fontSize: '16px' });
    this._text(0, 30, `Name: ${GameState.playerName}`);
    this._text(0, 52, `Money: $${GameState.money}`);
    const mins = Math.floor(GameState.playTimeSeconds / 60);
    this._text(0, 74, `Play Time: ${mins}m`);
    this._text(0, 96, `Badges: ${GameState.badges.length}/8`);
    AURELIA_BADGES.forEach((b, i) => {
      const has = GameState.badges.includes(b.id);
      this._text((i % 4) * 130, 118 + Math.floor(i / 4) * 24, has ? b.name : '???', { fontSize: '12px', color: has ? '#ffd76e' : '#444444' });
    });
  }

  _renderSave() {
    this._text(0, 0, 'SAVE GAME', { color: '#ffd76e', fontSize: '16px' });
    const btn = this._text(0, 34, '[ Press Z to Save ]', { color: '#4caf50' });
    this._saveHandler = () => {
      const ok = SaveSystem.save();
      this._clearContent();
      this._text(0, 0, 'SAVE GAME', { color: '#ffd76e', fontSize: '16px' });
      this._text(0, 34, ok ? 'Game saved!' : 'Save failed.', { color: ok ? '#4caf50' : '#e53935' });
    };
  }

  _renderOptions() {
    this._text(0, 0, 'OPTIONS', { color: '#ffd76e', fontSize: '16px' });
    this._text(0, 30, `Music Volume: ${Math.round(GameState.settings.musicVolume * 100)}%  (- / + not bound to keys yet, edit in Options screen)`, { fontSize: '12px' });
    this._text(0, 52, `SFX Volume: ${Math.round(GameState.settings.sfxVolume * 100)}%`, { fontSize: '12px' });
    this._text(0, 74, `Text Speed: ${GameState.settings.textSpeed}`, { fontSize: '12px' });
    this._text(0, 96, `Animations: ${GameState.settings.animations ? 'On' : 'Off'}`, { fontSize: '12px' });
    this._text(0, 130, 'Press X to close this menu.', { fontSize: '12px', color: '#888888' });
  }

  update() {
    if (TABS[this.tabIndex] === 'SAVE' && this._saveHandler && Phaser.Input.Keyboard.JustDown(this.input.keyboard.addKey('Z'))) {
      this._saveHandler();
    }
  }

  _close() {
    AudioSystem.playMenu();
    this.scene.stop();
    if (this.fromTitle) {
      this.scene.resume('TitleScene');
    } else {
      this.scene.resume('WorldScene');
    }
  }
}
