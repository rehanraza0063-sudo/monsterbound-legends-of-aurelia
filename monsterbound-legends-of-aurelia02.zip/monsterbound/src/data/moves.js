import { TYPES } from './types.js';

// Category: 'physical' | 'special' | 'status'
// Each type gets 6 template moves so the whole roster is generated, not hand-copied.
// This keeps the system data-driven: adding a 13th type just needs 6 new template rows.

const TEMPLATES = [
  { key: 'jab', category: 'physical', power: 40, accuracy: 100, pp: 35, suffix: 'Strike', effect: null },
  { key: 'mid', category: 'physical', power: 65, accuracy: 95, pp: 20, suffix: 'Slash', effect: null },
  { key: 'special', category: 'special', power: 70, accuracy: 95, pp: 15, suffix: 'Blast', effect: null },
  { key: 'heavy', category: 'physical', power: 95, accuracy: 80, pp: 10, suffix: 'Crush', effect: null },
  { key: 'buff', category: 'status', power: 0, accuracy: 100, pp: 20, suffix: 'Focus', effect: { kind: 'buff', stat: 'attack', stages: 1, target: 'self' } },
  { key: 'ailment', category: 'status', power: 0, accuracy: 85, pp: 15, suffix: 'Curse', effect: { kind: 'status', status: null, target: 'enemy' } }
];

const STATUS_BY_TYPE = {
  Flame: 'burn', Frost: 'freeze', Storm: 'shock', Nature: 'poison',
  Shadow: 'sleep', Mystic: 'confusion', Earth: 'poison', Aqua: 'confusion',
  Stone: 'shock', Light: 'confusion', Metal: 'freeze', Wind: 'sleep'
};

function generateTypedMoves() {
  const moves = [];
  let id = 1;
  for (const type of TYPES) {
    for (const t of TEMPLATES) {
      const move = {
        id: `M${String(id).padStart(3, '0')}`,
        name: `${type} ${t.suffix}`,
        type,
        category: t.category,
        power: t.power,
        accuracy: t.accuracy,
        pp: t.pp,
        maxPp: t.pp,
        description: t.category === 'status'
          ? `A ${type.toLowerCase()}-infused technique that alters the battle.`
          : `A ${type.toLowerCase()}-type attack that strikes the foe.`,
        effect: t.effect ? { ...t.effect, status: t.effect.kind === 'status' ? STATUS_BY_TYPE[type] : undefined } : null
      };
      moves.push(move);
      id++;
    }
  }
  return moves;
}

// Generic, non-elemental moves every monster line can learn early on.
const GENERIC_MOVES = [
  { name: 'Tackle', category: 'physical', power: 40, accuracy: 100, pp: 35, description: 'A full-body charge at the foe.' },
  { name: 'Scratch', category: 'physical', power: 35, accuracy: 100, pp: 35, description: 'Rakes the target with sharp claws.' },
  { name: 'Growl', category: 'status', power: 0, accuracy: 100, pp: 40, effect: { kind: 'debuff', stat: 'attack', stages: 1, target: 'enemy' }, description: 'Lowers the foe\'s Attack.' },
  { name: 'Harden', category: 'status', power: 0, accuracy: 100, pp: 30, effect: { kind: 'buff', stat: 'defense', stages: 1, target: 'self' }, description: 'Raises the user\'s Defense.' },
  { name: 'Quick Snap', category: 'physical', power: 30, accuracy: 100, pp: 30, priority: 1, description: 'A rapid strike that almost always goes first.' },
  { name: 'Rest', category: 'status', power: 0, accuracy: 100, pp: 10, effect: { kind: 'heal', percent: 50, target: 'self' }, description: 'The user rests, restoring some HP.' },
  { name: 'Protect', category: 'status', power: 0, accuracy: 100, pp: 10, effect: { kind: 'protect', target: 'self' }, description: 'Shields the user from the next attack.' },
  { name: 'Focus Charge', category: 'status', power: 0, accuracy: 100, pp: 20, effect: { kind: 'buff', stat: 'special', stages: 1, target: 'self' }, description: 'Raises the user\'s Special Attack.' },
  { name: 'Roar', category: 'status', power: 0, accuracy: 90, pp: 20, effect: { kind: 'debuff', stat: 'speed', stages: 1, target: 'enemy' }, description: 'Lowers the foe\'s Speed.' },
  { name: 'Bide Slam', category: 'physical', power: 55, accuracy: 100, pp: 20, description: 'A patient, weighty body slam.' },
  { name: 'Screech', category: 'status', power: 0, accuracy: 85, pp: 15, effect: { kind: 'debuff', stat: 'defense', stages: 1, target: 'enemy' }, description: 'A piercing cry that lowers Defense.' },
  { name: 'Rally', category: 'status', power: 0, accuracy: 100, pp: 15, effect: { kind: 'buff', stat: 'speed', stages: 1, target: 'self' }, description: 'Raises the user\'s Speed.' },
  { name: 'Double Hit', category: 'physical', power: 25, accuracy: 90, pp: 15, hits: 2, description: 'Strikes twice in a row.' },
  { name: 'Guard Down', category: 'status', power: 0, accuracy: 100, pp: 20, effect: { kind: 'debuff', stat: 'special', stages: 1, target: 'enemy' }, description: 'Lowers the foe\'s Special Defense.' },
  { name: 'Bind', category: 'physical', power: 20, accuracy: 85, pp: 20, effect: { kind: 'status', status: 'confusion', target: 'enemy', chance: 20 }, description: 'Grapples the foe, sometimes confusing it.' },
  { name: 'Recover', category: 'status', power: 0, accuracy: 100, pp: 5, effect: { kind: 'heal', percent: 60, target: 'self' }, description: 'Restores a large portion of HP.' },
  { name: 'Endure', category: 'status', power: 0, accuracy: 100, pp: 10, effect: { kind: 'endure', target: 'self' }, description: 'The user endures any hit with 1 HP.' },
  { name: 'Struggle', category: 'physical', power: 50, accuracy: 100, pp: 1, description: 'A last-resort attack used only when out of PP.' },
  { name: 'Copycat', category: 'status', power: 0, accuracy: 100, pp: 15, effect: { kind: 'buff', stat: 'attack', stages: 2, target: 'self' }, description: 'Sharply raises the user\'s Attack.' },
  { name: 'Bravado', category: 'physical', power: 80, accuracy: 100, pp: 10, description: 'A brave, all-out physical charge.' }
];

// A handful of signature moves for starters and legendaries.
const SIGNATURE_MOVES = [
  { name: 'Emberflare Fang', type: 'Flame', category: 'physical', power: 75, accuracy: 100, pp: 15, description: 'Signature bite wreathed in flame.' },
  { name: 'Shellguard Slam', type: 'Nature', category: 'physical', power: 75, accuracy: 100, pp: 15, description: 'Signature shell-first body slam.' },
  { name: 'Tidewave Pulse', type: 'Aqua', category: 'special', power: 75, accuracy: 100, pp: 15, description: 'Signature pulse of surging water.' },
  { name: 'Skybreaker Roar', type: 'Storm', category: 'special', power: 110, accuracy: 90, pp: 5, description: 'A legendary cry that splits the sky.' },
  { name: 'Abysswatch Gaze', type: 'Shadow', category: 'special', power: 110, accuracy: 90, pp: 5, description: 'A legendary stare from the deep dark.' },
  { name: 'Sunspire Judgment', type: 'Light', category: 'special', power: 110, accuracy: 90, pp: 5, description: 'A legendary beam of pure radiance.' },
  { name: 'Aurelian Genesis', type: 'Mystic', category: 'special', power: 120, accuracy: 85, pp: 5, description: 'The ancient move said to have shaped Aurelia itself.' },
  { name: 'Rootbound Wrath', type: 'Earth', category: 'physical', power: 90, accuracy: 90, pp: 10, description: 'Calls the fury of the deep earth.' },
  { name: 'Glacial Requiem', type: 'Frost', category: 'special', power: 90, accuracy: 90, pp: 10, description: 'A mournful, freezing final wave.' },
  { name: 'Ironclad Verdict', type: 'Metal', category: 'physical', power: 90, accuracy: 90, pp: 10, description: 'A crushing, unstoppable metal blow.' }
];

function assignIds(list, startId) {
  return list.map((m, i) => ({
    id: `M${String(startId + i).padStart(3, '0')}`,
    maxPp: m.pp,
    ...m
  }));
}

const typedMoves = generateTypedMoves(); // 72 moves (12 types x 6)
const genericMoves = assignIds(GENERIC_MOVES, typedMoves.length + 1); // 20 moves
const signatureMoves = assignIds(SIGNATURE_MOVES, typedMoves.length + genericMoves.length + 1); // 10 moves

export const MOVES = [...typedMoves, ...genericMoves, ...signatureMoves];
export const MOVES_BY_ID = Object.fromEntries(MOVES.map(m => [m.id, m]));
export const MOVES_BY_NAME = Object.fromEntries(MOVES.map(m => [m.name, m]));

export function getMovesForType(type, count = 4) {
  return MOVES.filter(m => m.type === type).slice(0, count).map(m => m.id);
}
