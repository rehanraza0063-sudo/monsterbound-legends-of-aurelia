// Data-driven map system.
// Legend characters:
//   . grass (walkable)      # tree/wall (solid)      ~ water (solid, needs future ability)
//   : tall grass (walkable, triggers wild encounter checks)
//   , path/floor (walkable) B building wall (solid)   D door (walkable, may be a warp)
//   H healing center tile (walkable, interact = heal) S shop tile (walkable, interact = shop)
//   G gym entrance (walkable, interact = gym battle)
// Maps are intentionally modest in size (grid-based, 32px tiles) so the whole
// slice is genuinely playable; see README "Adding Maps" for how to add the
// remaining regions listed in data/story.js using this same structure.

export const TILE_SIZE = 32;

export const TILE_LEGEND = {
  '.': { solid: false, color: 0x4caf50 },
  ':': { solid: false, color: 0x2e7d32, encounter: true },
  ',': { solid: false, color: 0xd7ccc8 },
  '#': { solid: true, color: 0x2e4d2e },
  '~': { solid: true, color: 0x2e86ab },
  B: { solid: true, color: 0x7a5c3e },
  D: { solid: false, color: 0xc9a876, warpTile: true },
  H: { solid: false, color: 0xff8fa3, heal: true },
  S: { solid: false, color: 0xffd54f, shop: true },
  G: { solid: false, color: 0x9575cd, gym: 'gym1' }
};

function grid(rows) {
  return rows.map(r => r.split(''));
}

export const MAPS = {
  starting_village: {
    id: 'starting_village', name: 'Starting Village',
    layout: grid([
      '####################',
      '#..................#',
      '#..B B........B B..#',
      '#..B B........B B..#',
      '#..................#',
      '#.......BBBB.......#',
      '#.......BHBB.......#',
      '#.......BDBB.......#',
      '#..................#',
      '#..................#',
      '#....S........lab..#',
      '#....D........BBB..#',
      '#..................#',
      '#..................#',
      '####...........#####',
      '####.............###',
      '#####.............##',
      '####################'
    ]),
    spawn: { x: 10, y: 10 },
    npcs: [
      { id: 'professor_aria', x: 15, y: 10, sprite: 'npc_scientist', name: 'Professor Aria',
        dialogue: ["Welcome to Aurelia! I'm Professor Aria.", "It's dangerous to explore without a monster companion.", "Go ahead - choose the one that speaks to you."],
        givesStarterChoice: true },
      { id: 'village_elder', x: 5, y: 3, sprite: 'npc_elder', name: 'Elder Boro',
        dialogue: ["Corin's been looking for you.", "That kid always wants to battle the moment they wake up."] },
      { id: 'rival_corin_1', x: 12, y: 12, sprite: 'npc_rival', name: 'Corin', isRival: true,
        dialogue: ["There you are! Got your starter yet?", "Let's battle - don't hold back!"],
        battleOnTalk: 'rival_1' }
    ],
    warps: [
      { x: 10, y: 15, toMap: 'greenmeadow_route', toX: 10, toY: 1 }
    ],
    encounterTable: []
  },

  greenmeadow_route: {
    id: 'greenmeadow_route', name: 'Greenmeadow Route',
    layout: grid([
      '####################',
      '#.........D........#',
      '#..:::..........::.#',
      '#..:::....##....::.#',
      '#..:::....##....::.#',
      '#..................#',
      '#....::::......::..#',
      '#....::::......::..#',
      '#..................#',
      '#..::........::....#',
      '#..::........::....#',
      '#..................#',
      '#........D.........#',
      '####################'
    ]),
    spawn: { x: 10, y: 1 },
    npcs: [
      { id: 'ranger_1', x: 4, y: 6, sprite: 'npc_ranger', name: 'Ranger Talo', trainerClass: 'Ranger',
        dialogue: ['These routes are full of wild monsters. Watch your step!'], trainerBattle: { levelRange: [4, 6], speciesPool: ['Zephyl', 'Pebblin', 'Ripplet'] } }
    ],
    warps: [
      { x: 10, y: 0, toMap: 'starting_village', toX: 10, toY: 14 },
      { x: 10, y: 13, toMap: 'lumina_city', toX: 10, toY: 1 }
    ],
    encounterTable: [
      { speciesName: 'Zephyl', weight: 30, levelRange: [3, 5] },
      { speciesName: 'Pebblin', weight: 25, levelRange: [3, 5] },
      { speciesName: 'Ripplet', weight: 25, levelRange: [3, 5] },
      { speciesName: 'Sproutle', weight: 20, levelRange: [3, 6] }
    ],
    encounterRate: 0.12
  },

  lumina_city: {
    id: 'lumina_city', name: 'Lumina City',
    layout: grid([
      '####################',
      '#.........D........#',
      '#..................#',
      '#..BBB......BBBBB..#',
      '#..BSB......BGBBB..#',
      '#..BDB......BDBBB..#',
      '#..................#',
      '#..BBB..........BBB#',
      '#..BHB..........B.B#',
      '#..BDB..........BDB#',
      '#..................#',
      '####################'
    ]),
    spawn: { x: 10, y: 1 },
    npcs: [
      { id: 'gym_guide', x: 12, y: 5, sprite: 'npc_scientist', name: 'Gym Attendant',
        dialogue: ['Bren, our Flame Leader, is waiting inside. Good luck!'] },
      { id: 'quest_giver_1', x: 3, y: 7, sprite: 'npc_collector', name: 'Collector Finn',
        dialogue: ['I heard a rare monster is hiding near Greenmeadow Route...'], questId: 'side_02_lost_capsule' }
    ],
    warps: [
      { x: 10, y: 0, toMap: 'greenmeadow_route', toX: 10, toY: 12 },
      { x: 13, y: 5, toMap: 'whisperwood_forest', toX: 10, toY: 12 }
    ],
    encounterTable: []
  },

  whisperwood_forest: {
    id: 'whisperwood_forest', name: 'Whisperwood Forest',
    layout: grid([
      '####################',
      '#..#####..####.....#',
      '#..#:::#..#::#..::.#',
      '#..#:::#..#::#..::.#',
      '#..#####..####.....#',
      '#..................#',
      '#..::::::....::::..#',
      '#..::::::....::::..#',
      '#..................#',
      '#....##......##....#',
      '#....##......##....#',
      '#..................#',
      '#.........D........#',
      '####################'
    ]),
    spawn: { x: 10, y: 12 },
    npcs: [
      { id: 'relic_npc', x: 3, y: 6, sprite: 'npc_explorer', name: 'Explorer Mabel',
        dialogue: ['I dropped an old relic somewhere in this forest...', 'Could you find it for me?'], questId: 'side_01_whisperwood_relic' },
      { id: 'eclipse_grunt_1', x: 16, y: 6, sprite: 'npc_villain', name: 'Eclipse Grunt', trainerClass: 'Villain Grunt',
        dialogue: ['The Order has business here. Stay out of our way!'], trainerBattle: { levelRange: [10, 12], speciesPool: ['Gloomit', 'Murkin'] },
        questId: 'main_04_eclipse_whisperwood' }
    ],
    warps: [
      { x: 10, y: 12, toMap: 'lumina_city', toX: 13, toY: 6 },
      { x: 10, y: 0, toMap: 'riverdale_town', toX: 10, toY: 12 }
    ],
    encounterTable: [
      { speciesName: 'Sproutle', weight: 30, levelRange: [8, 11] },
      { speciesName: 'Mossle', weight: 25, levelRange: [8, 11] },
      { speciesName: 'Gloomit', weight: 20, levelRange: [9, 12] },
      { speciesName: 'Runelt', weight: 15, levelRange: [9, 13] },
      { speciesName: 'Leafenoth', weight: 10, levelRange: [10, 13] }
    ],
    encounterRate: 0.14
  },

  riverdale_town: {
    id: 'riverdale_town', name: 'Riverdale Town',
    layout: grid([
      '####################',
      '#.........D........#',
      '#..................#',
      '#..BBB..~~~~..BBB..#',
      '#..BSB..~~~~..BGB..#',
      '#..BDB..~~~~..BDB..#',
      '#..........~~~~....#',
      '#..BBB.....~~~~....#',
      '#..BHB..............#',
      '#..BDB..............#',
      '#..................#',
      '####################'
    ]),
    spawn: { x: 10, y: 1 },
    npcs: [
      { id: 'talia_hint', x: 14, y: 5, sprite: 'npc_scientist', name: 'Dockhand',
        dialogue: ['Talia, our Tide Leader, trains out on the water platform.'] }
    ],
    warps: [
      { x: 10, y: 0, toMap: 'whisperwood_forest', toX: 10, toY: 1 },
      { x: 10, y: 10, toMap: 'mist_cave', toX: 10, toY: 1 }
    ],
    encounterTable: []
  },

  mist_cave: {
    id: 'mist_cave', name: 'Mist Cave',
    layout: grid([
      '####################',
      '#.........D........#',
      '#..................#',
      '#..####......####..#',
      '#..#..#......#..#..#',
      '#..#..########..#..#',
      '#..#............#..#',
      '#..#..########..#..#',
      '#..#..#......#..#..#',
      '#..####......####..#',
      '#..................#',
      '####################'
    ]),
    spawn: { x: 10, y: 1 },
    npcs: [
      { id: 'old_door_flag', x: 10, y: 6, sprite: 'npc_hidden', name: 'Rusted Door',
        dialogue: ['A rusted door, sealed shut. It looks like it needs an old key.'], questId: 'hidden_01_old_key', isFeature: true }
    ],
    warps: [
      { x: 10, y: 0, toMap: 'riverdale_town', toX: 10, toY: 9 }
    ],
    encounterTable: [
      { speciesName: 'Pebblin', weight: 25, levelRange: [14, 18] },
      { speciesName: 'Craggle', weight: 25, levelRange: [14, 18] },
      { speciesName: 'Ferrix', weight: 20, levelRange: [15, 19] },
      { speciesName: 'Gloomit', weight: 15, levelRange: [15, 19] },
      { speciesName: 'Duskrath', weight: 15, levelRange: [17, 20] }
    ],
    encounterRate: 0.16
  }
};

export const MAP_IDS = Object.keys(MAPS);
