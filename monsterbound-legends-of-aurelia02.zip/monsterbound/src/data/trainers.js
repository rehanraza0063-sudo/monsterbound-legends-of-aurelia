// Trainer party entries reference monster dex IDs from monsters.js by name lookup
// at load time (done lazily in systems/BattleSystem.js / WorldScene) so this file
// stays purely data-driven and human-editable.

export const TRAINER_CLASSES = [
  'Rookie Trainer', 'Explorer', 'Scientist', 'Ranger', 'Knight',
  'Collector', 'Ace Trainer', 'Villain Grunt', 'Villain Commander'
];

// Gym / Boss Leaders - one per elemental theme, per spec section 15.
export const GYM_LEADERS = [
  {
    id: 'gym1', order: 1, name: 'Bren', title: 'Flame Leader', city: 'Lumina City', type: 'Flame',
    theme: 'A gym built like a forge, with puzzle-lit torch switches.',
    dialogueIntro: "The forge never lies. Let's see if your fire burns as hot as mine!",
    dialogueDefeat: 'You... you really do have fire in you. Take this badge.',
    party: [{ speciesName: 'Cindragon', level: 14 }, { speciesName: 'Emberoar', level: 16 }],
    badge: 'flame_badge', reward: { money: 1500 }
  },
  {
    id: 'gym2', order: 2, name: 'Talia', title: 'Tide Leader', city: 'Riverdale Town', type: 'Aqua',
    theme: 'A floating dock arena over the Riverdale reservoir.',
    dialogueIntro: 'The river always finds a way through. Can you keep up?',
    dialogueDefeat: 'Impressive. The current bends to you now.',
    party: [{ speciesName: 'Fintidan', level: 20 }, { speciesName: 'Wavelurk', level: 22 }],
    badge: 'tide_badge', reward: { money: 2200 }
  },
  {
    id: 'gym3', order: 3, name: 'Rowan', title: 'Nature Leader', city: 'Ironhold City', type: 'Nature',
    theme: 'A hidden greenhouse arena inside the industrial city.',
    dialogueIntro: 'Even in a city of metal, life always finds root.',
    dialogueDefeat: 'You have a gardener\'s patience and a fighter\'s heart.',
    party: [{ speciesName: 'Leafenoth', level: 26 }, { speciesName: 'Vinelash', level: 28 }],
    badge: 'nature_badge', reward: { money: 2800 }
  },
  {
    id: 'gym4', order: 4, name: 'Koda', title: 'Storm Leader', city: 'Sunridge City', type: 'Storm',
    theme: 'An open-air arena on a lightning-rod tower.',
    dialogueIntro: 'Storms don\'t ask permission. Neither will I.',
    dialogueDefeat: 'The sky itself seems calmer now that you\'ve won.',
    party: [{ speciesName: 'Boltyric', level: 32 }, { speciesName: 'Thundipex', level: 34 }],
    badge: 'storm_badge', reward: { money: 3400 }
  },
  {
    id: 'gym5', order: 5, name: 'Marla', title: 'Stone Leader', city: 'Oasis Town', type: 'Stone',
    theme: 'An arena carved from ancient desert rock.',
    dialogueIntro: 'The desert wears down everything eventually. Even you.',
    dialogueDefeat: 'Sturdy stone, meet an even sturdier trainer.',
    party: [{ speciesName: 'Craggorn', level: 38 }, { speciesName: 'Bouldenoth', level: 40 }],
    badge: 'stone_badge', reward: { money: 4000 }
  },
  {
    id: 'gym6', order: 6, name: 'Ysolde', title: 'Shadow Leader', city: 'Coastal City', type: 'Shadow',
    theme: 'A dim arena lit only by bioluminescent tidepools.',
    dialogueIntro: 'In the dark, only the prepared survive.',
    dialogueDefeat: 'You brought your own light. Well fought.',
    party: [{ speciesName: 'Duskrath', level: 44 }, { speciesName: 'Umbrixis', level: 46 }],
    badge: 'shadow_badge', reward: { money: 4600 }
  },
  {
    id: 'gym7', order: 7, name: 'Denton', title: 'Metal Leader', city: 'Skyridge City', type: 'Metal',
    theme: 'A mechanized arena of moving gears and platforms.',
    dialogueIntro: 'Precision. Discipline. That\'s how metal is forged. And champions.',
    dialogueDefeat: 'Unbreakable, until today.',
    party: [{ speciesName: 'Boltronix', level: 50 }, { speciesName: 'Alloytus', level: 52 }],
    badge: 'metal_badge', reward: { money: 5200 }
  },
  {
    id: 'gym8', order: 8, name: 'Serath', title: 'Mystic Leader', city: 'Final Region', type: 'Mystic',
    theme: 'A ruined mystic sanctum at the edge of the known world.',
    dialogueIntro: 'You\'ve come far. Let\'s see if far enough.',
    dialogueDefeat: 'The last badge is yours. The championship awaits.',
    party: [{ speciesName: 'Enigmara', level: 56 }, { speciesName: 'Arcanetra', level: 58 }],
    badge: 'mystic_badge', reward: { money: 6000 }
  }
];

// Rival character - appears repeatedly across the story with a growing party.
export const RIVAL = {
  name: 'Corin',
  encounters: [
    { location: 'Starting Village', level: 5, dialogue: "Hey! Let's see whose starter is stronger." },
    { location: 'Lumina City', level: 15, dialogue: "I've been training hard. Don't hold back." },
    { location: 'Riverdale Town', level: 24, dialogue: "You beat the Tide Leader too? Guess I need to catch up." },
    { location: 'Mountain Pass', level: 35, dialogue: "The Eclipse Order is up to something. But first - a battle." },
    { location: 'Ancient Ruins', level: 48, dialogue: "This ancient power... it changes things. I need to be stronger." },
    { location: 'Championship', level: 60, dialogue: "This is it. Our final battle, as equals." }
  ]
};

// The villain organization.
export const ECLIPSE_ORDER = {
  name: 'The Eclipse Order',
  description: 'A secretive organization investigating ancient monsters in order to control legendary creatures.',
  leader: { name: 'Director Vael', title: 'Eclipse Director' },
  commanders: [
    { name: 'Commander Ashka', speciality: 'Shadow-type specialist' },
    { name: 'Commander Renn', speciality: 'Metal-type specialist' }
  ],
  scientist: { name: 'Dr. Imra Voss', role: 'Leads research into ancient monster origins' },
  headquarters: 'Eclipse Spire, hidden beneath the Ancient Ruins',
  missions: [
    { chapter: 2, name: 'Strange Signals in Whisperwood', summary: 'Grunts are seen tampering with wild monsters in the forest.' },
    { chapter: 4, name: 'The Mist Cave Excavation', summary: 'The Order is digging for something beneath Mist Cave.' },
    { chapter: 6, name: 'Raid on Ironhold Labs', summary: 'Commander Renn attempts to steal Gym research data.' },
    { chapter: 8, name: 'The Ancient Ruins Awaken', summary: 'Director Vael attempts to awaken a legendary monster.' },
    { chapter: 9, name: 'Fall of Eclipse Spire', summary: 'Final confrontation with the Eclipse Order.' }
  ]
};

// Template used to generate generic trainers throughout the world (data-driven,
// so WorldScene/maps.js can spawn many trainers without hand-writing each one).
export function generateGenericTrainer(trainerClass, levelRange, speciesPool, name) {
  const [minL, maxL] = levelRange;
  const count = trainerClass === 'Villain Commander' ? 3 : (trainerClass === 'Ace Trainer' ? 3 : 2);
  const party = [];
  for (let i = 0; i < count; i++) {
    const species = speciesPool[Math.floor(Math.random() * speciesPool.length)];
    const level = minL + Math.floor(Math.random() * (maxL - minL + 1));
    party.push({ speciesName: species, level });
  }
  return {
    id: `${trainerClass}-${name}`.replace(/\s+/g, '_'),
    name, class: trainerClass, party,
    reward: { money: (minL + maxL) * 20 }
  };
}
