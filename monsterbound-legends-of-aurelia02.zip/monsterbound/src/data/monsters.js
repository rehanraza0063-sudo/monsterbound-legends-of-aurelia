import { TYPES } from './types.js';
import { MOVES } from './moves.js';

// ---------------------------------------------------------------------------
// MONSTERBOUND species database.
// Fully data-driven: every species is a plain object. To add Monster #151,
// just append to STARTERS, LEGENDARIES, or extend NAME_ROOTS and re-run the
// generator loop below - no battle/UI code needs to change (see README).
// ---------------------------------------------------------------------------

const RARITY = ['common', 'uncommon', 'rare', 'very rare', 'legendary'];

// Two name-fragments per type, used to build an evolution line's two names.
// e.g. Flame -> base "Cindle", evolved "Cindragon"
const NAME_ROOTS = {
  Flame: [['Cindle', 'Cindragon'], ['Emberit', 'Emberoar'], ['Pyrell', 'Pyrellix'], ['Scorchip', 'Scorchara'], ['Blazon', 'Blazonyx']],
  Aqua: [['Ripplet', 'Ripplord'], ['Fintide', 'Fintidan'], ['Wavelet', 'Wavelurk'], ['Brinny', 'Brinaxus'], ['Tidewyn', 'Tidewynne']],
  Nature: [['Sproutle', 'Sproutessa'], ['Mossle', 'Mossaur'], ['Leafen', 'Leafenoth'], ['Budrik', 'Budrikoth'], ['Vinelet', 'Vinelash']],
  Storm: [['Zappid', 'Zappidon'], ['Gustrix', 'Gustrixis'], ['Boltyn', 'Boltyric'], ['Cracklet', 'Cracklurk'], ['Thundip', 'Thundipex']],
  Stone: [['Pebblin', 'Pebblorn'], ['Craggle', 'Craggorn'], ['Boulden', 'Bouldenoth'], ['Rockit', 'Rockitan'], ['Gravlet', 'Gravlithe']],
  Frost: [['Chilby', 'Chilbrax'], ['Snowlet', 'Snowlurn'], ['Iciclet', 'Icicloth'], ['Frostiv', 'Frostivex'], ['Glacett', 'Glacettan']],
  Shadow: [['Gloomit', 'Gloomorra'], ['Dusklet', 'Duskrath'], ['Murkin', 'Murkinox'], ['Umbrix', 'Umbrixis'], ['Shadowl', 'Shadowlyn']],
  Light: [['Glimmit', 'Glimmoria'], ['Radish', 'Radiance'], ['Lucenn', 'Lucennia'], ['Beamet', 'Beametrix'], ['Shinelt', 'Shineltra']],
  Metal: [['Ferrix', 'Ferrixon'], ['Steeln', 'Steelnox'], ['Boltron', 'Boltronix'], ['Alloyt', 'Alloytus'], ['Coggle', 'Coggleth']],
  Wind: [['Zephyl', 'Zephyrra'], ['Breezit', 'Breezitan'], ['Gustlet', 'Gustlyn'], ['Wispet', 'Wispetra'], ['Aeriel', 'Aerielon']],
  Mystic: [['Runelt', 'Runeltis'], ['Enigmy', 'Enigmara'], ['Charmet', 'Charmetra'], ['Wisplin', 'Wisplindra'], ['Arcanet', 'Arcanetra']],
  Earth: [['Terrik', 'Terrikon'], ['Loamet', 'Loametta'], ['Clodrin', 'Clodrinox'], ['Sandit', 'Sanditan'], ['Duston', 'Dustonyx']]
};

const HABITATS = {
  Flame: 'Volcanic Region', Aqua: 'Riverdale Shores', Nature: 'Whisperwood Forest',
  Storm: 'Mountain Pass', Stone: 'Mist Cave', Frost: 'Skyridge Peaks',
  Shadow: 'Ancient Ruins', Light: 'Sunridge Fields', Metal: 'Ironhold Mines',
  Wind: 'Greenmeadow Route', Mystic: 'Oasis Town', Earth: 'Golden Desert'
};

function statBlock(base, spread) {
  // spread lets each line lean toward different roles (0=low,1=med,2=high)
  const [hp, atk, def, spd, satk, sdef] = spread;
  return {
    hp: base + hp * 8,
    attack: base + atk * 8,
    defense: base + def * 8,
    speed: base + spd * 8,
    specialAttack: base + satk * 8,
    specialDefense: base + sdef * 8
  };
}

// deterministic pseudo-variety generator per line index so stat spreads differ
function spreadFor(lineIndex) {
  const patterns = [
    [2, 2, 1, 1, 1, 1], // balanced-ish
    [1, 3, 2, 0, 1, 1], // physical attacker
    [1, 1, 3, 0, 1, 2], // tank
    [1, 0, 1, 3, 2, 1], // speedster/special
    [3, 1, 1, 0, 1, 2]  // bulky
  ];
  return patterns[lineIndex % patterns.length];
}

function movesetFor(type, tier) {
  const typed = MOVES.filter(m => m.type === type);
  const generic = MOVES.filter(m => !m.type);
  const learnset = [];
  learnset.push({ level: 1, moveId: generic.find(m => m.name === 'Tackle').id });
  learnset.push({ level: 1, moveId: generic.find(m => m.name === 'Growl').id });
  learnset.push({ level: 5, moveId: typed[0].id });
  learnset.push({ level: 10, moveId: generic.find(m => m.name === 'Harden').id });
  learnset.push({ level: 14, moveId: typed[1].id });
  learnset.push({ level: 20, moveId: typed[4].id }); // buff move
  learnset.push({ level: 24, moveId: typed[2].id });
  learnset.push({ level: 30, moveId: generic.find(m => m.name === 'Rally').id });
  learnset.push({ level: 36 + tier * 4, moveId: typed[3].id }); // heavy hit later for higher tiers
  learnset.push({ level: 42, moveId: typed[5].id }); // ailment move
  return learnset;
}

let dexId = 1;
const MONSTERS = [];

// --- 3 original starters, hand-authored (per section 6 of the spec) ---
const STARTER_DEFS = [
  {
    lineName: ['Emberfox', 'Emberwyld'], type: 'Flame', spread: [1, 3, 1, 2, 2, 1],
    desc: 'A quick, fiery fox-like companion whose tail smolders when excited.'
  },
  {
    lineName: ['Mosshell', 'Mosshollow'], type: 'Nature', spread: [3, 1, 3, 0, 1, 2],
    desc: 'A calm, armored creature that carries a small garden on its back.'
  },
  {
    lineName: ['Aquafin', 'Aquafinne'], type: 'Aqua', spread: [2, 2, 2, 2, 2, 2],
    desc: 'A balanced, finned companion at home in rivers and lakes alike.'
  }
];

export const STARTER_IDS = [];
for (const s of STARTER_DEFS) {
  const baseId = dexId++;
  const evoId = dexId++;
  STARTER_IDS.push(baseId);
  MONSTERS.push({
    id: baseId, name: s.lineName[0], type: [s.type], rarity: 'common',
    description: s.desc, habitat: 'Starting Village', category: 'starter',
    base: statBlock(38, s.spread), captureRate: 45,
    xpToLevel: 1.1, abilities: [`${s.type} Heart`],
    evolvesTo: evoId, evolvesAtLevel: 16,
    learnset: movesetFor(s.type, 1)
  });
  MONSTERS.push({
    id: evoId, name: s.lineName[1], type: [s.type], rarity: 'uncommon',
    description: `The evolved form of ${s.lineName[0]}, stronger and more resolute.`,
    habitat: 'Starting Village', category: 'starter',
    base: statBlock(58, s.spread.map(v => v + 1)), captureRate: 25,
    xpToLevel: 1.2, abilities: [`${s.type} Spirit`],
    evolvesFrom: baseId,
    learnset: movesetFor(s.type, 2)
  });
}

// --- Generated wild monster lines: 12 types x 5 lines x 2 stages = 120 ---
for (const type of TYPES) {
  const lines = NAME_ROOTS[type];
  lines.forEach((namePair, lineIndex) => {
    const spread = spreadFor(lineIndex);
    const rarityTier = lineIndex < 3 ? 'common' : (lineIndex === 3 ? 'uncommon' : 'rare');
    const baseId = dexId++;
    const evoId = dexId++;
    const evolveLevel = 14 + lineIndex * 4;
    MONSTERS.push({
      id: baseId, name: namePair[0], type: [type], rarity: rarityTier,
      description: `A ${rarityTier} wild monster native to ${HABITATS[type]}, first stage of its line.`,
      habitat: HABITATS[type], category: 'wild',
      base: statBlock(30 + lineIndex * 2, spread), captureRate: rarityTier === 'common' ? 60 : (rarityTier === 'uncommon' ? 40 : 25),
      xpToLevel: 1.0 + lineIndex * 0.05, abilities: [`${type} Sense`],
      evolvesTo: evoId, evolvesAtLevel: evolveLevel,
      learnset: movesetFor(type, lineIndex)
    });
    MONSTERS.push({
      id: evoId, name: namePair[1], type: [type], rarity: rarityTier === 'rare' ? 'very rare' : (rarityTier === 'uncommon' ? 'rare' : 'uncommon'),
      description: `The evolved form of ${namePair[0]}, a formidable presence in ${HABITATS[type]}.`,
      habitat: HABITATS[type], category: 'wild',
      base: statBlock(52 + lineIndex * 3, spread.map(v => v + 1)), captureRate: rarityTier === 'common' ? 30 : 15,
      xpToLevel: 1.1 + lineIndex * 0.05, abilities: [`${type} Mastery`],
      evolvesFrom: baseId,
      learnset: movesetFor(type, lineIndex + 1)
    });
  });
}

// --- 3 legendary ancient monsters tied to the main story ---
const LEGENDARY_DEFS = [
  { name: 'Skybrand Zephyros', type: 'Storm', desc: 'An ancient guardian said to ride the highest storms above Aurelia.' },
  { name: 'Duskwarden Nyxeth', type: 'Shadow', desc: 'A silent watcher that has slept beneath the Ancient Ruins for centuries.' },
  { name: 'Dawnherald Solenne', type: 'Light', desc: 'A radiant being believed to have helped shape Aurelia itself.' }
];
export const LEGENDARY_IDS = [];
for (const l of LEGENDARY_DEFS) {
  const id = dexId++;
  LEGENDARY_IDS.push(id);
  MONSTERS.push({
    id, name: l.name, type: [l.type], rarity: 'legendary',
    description: l.desc, habitat: 'Unknown', category: 'legendary',
    base: statBlock(100, [3, 3, 3, 3, 3, 3]), captureRate: 3,
    xpToLevel: 1.5, abilities: ['Ancient Power'],
    learnset: movesetFor(l.type, 4)
  });
}

export const MONSTER_COUNT = MONSTERS.length;
export const MONSTERS_BY_ID = Object.fromEntries(MONSTERS.map(m => [m.id, m]));
export { MONSTERS };

export function getSpecies(id) {
  return MONSTERS_BY_ID[id];
}

export function speciesByRarity(rarity) {
  return MONSTERS.filter(m => m.rarity === rarity);
}

export function speciesByHabitat(habitat) {
  return MONSTERS.filter(m => m.habitat === habitat);
}
