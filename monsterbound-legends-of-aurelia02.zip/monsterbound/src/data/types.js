// 12 original elemental types + full effectiveness chart.
export const TYPES = [
  'Flame', 'Aqua', 'Nature', 'Storm', 'Stone', 'Frost',
  'Shadow', 'Light', 'Metal', 'Wind', 'Mystic', 'Earth'
];

export const TYPE_COLORS = {
  Flame: 0xe25822, Aqua: 0x2e86ab, Nature: 0x4caf50, Storm: 0x8e44ad,
  Stone: 0x9b7653, Frost: 0x7fdbff, Shadow: 0x4b0082, Light: 0xf5d76e,
  Metal: 0xb0b0b0, Wind: 0x7fffd4, Mystic: 0xd291bc, Earth: 0x8b5a2b
};

// super-effective-against map: TYPE -> [types it deals 2x damage to]
const SUPER_EFFECTIVE = {
  Flame: ['Nature', 'Frost', 'Metal'],
  Aqua: ['Flame', 'Stone', 'Earth'],
  Nature: ['Aqua', 'Earth', 'Stone'],
  Storm: ['Aqua', 'Wind', 'Metal'],
  Stone: ['Flame', 'Wind', 'Frost'],
  Frost: ['Nature', 'Wind', 'Earth'],
  Shadow: ['Mystic', 'Light', 'Shadow'],
  Light: ['Shadow', 'Mystic'],
  Metal: ['Stone', 'Frost', 'Light'],
  Wind: ['Nature', 'Earth'],
  Mystic: ['Storm', 'Shadow'],
  Earth: ['Metal', 'Flame', 'Storm']
};

// not-very-effective-against map: TYPE -> [types it deals 0.5x damage to]
const NOT_VERY_EFFECTIVE = {
  Flame: ['Aqua', 'Stone', 'Earth'],
  Aqua: ['Nature', 'Storm'],
  Nature: ['Flame', 'Wind', 'Metal'],
  Storm: ['Stone', 'Earth'],
  Stone: ['Metal', 'Earth'],
  Frost: ['Flame', 'Metal'],
  Shadow: ['Light'],
  Light: ['Metal', 'Stone'],
  Metal: ['Flame', 'Storm'],
  Wind: ['Stone', 'Metal'],
  Mystic: ['Metal'],
  Earth: ['Nature', 'Wind']
};

// immune map: TYPE -> [types it deals 0x damage to]
const IMMUNE = {
  Storm: ['Earth'],
  Earth: ['Storm'],
  Shadow: [],
  Light: []
};

export function typeEffectiveness(attackType, defendTypes) {
  // defendTypes: array of 1-2 types
  let multiplier = 1;
  for (const def of defendTypes) {
    if (IMMUNE[attackType] && IMMUNE[attackType].includes(def)) return 0;
    if (SUPER_EFFECTIVE[attackType] && SUPER_EFFECTIVE[attackType].includes(def)) multiplier *= 2;
    else if (NOT_VERY_EFFECTIVE[attackType] && NOT_VERY_EFFECTIVE[attackType].includes(def)) multiplier *= 0.5;
  }
  return multiplier;
}

export function effectivenessLabel(mult) {
  if (mult === 0) return 'It has no effect...';
  if (mult >= 2) return "It's super effective!";
  if (mult <= 0.5) return "It's not very effective...";
  return null;
}
