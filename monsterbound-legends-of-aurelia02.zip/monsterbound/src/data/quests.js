export const QUESTS = [
  {
    id: 'main_01_choose_starter', type: 'main', chapter: 'PROLOGUE',
    name: 'A New Journey', description: 'Choose your first monster companion from Professor Aria.',
    steps: ['Talk to Professor Aria', 'Choose your starter monster'],
    reward: { money: 500, items: [{ id: 'basic_capsule', qty: 5 }] }
  },
  {
    id: 'main_02_reach_lumina', type: 'main', chapter: 'CHAPTER 1',
    name: 'Road to Lumina', description: 'Travel along Greenmeadow Route to reach Lumina City.',
    steps: ['Leave Starting Village', 'Arrive at Lumina City'],
    reward: { money: 300 }
  },
  {
    id: 'main_03_flame_badge', type: 'main', chapter: 'CHAPTER 1',
    name: 'The Flame Leader', description: 'Challenge Bren, the Flame Leader, at the Lumina City Gym.',
    steps: ['Enter the Lumina Gym', 'Defeat Bren'],
    reward: { money: 1500, items: [{ id: 'super_potion', qty: 3 }] }
  },
  {
    id: 'side_01_whisperwood_relic', type: 'side', chapter: 'CHAPTER 1',
    name: 'Voices in Whisperwood', description: 'An NPC asks you to recover a relic lost in Whisperwood Forest.',
    steps: ['Find the Whisperwood Relic', 'Return it to the NPC'],
    reward: { money: 800, items: [{ id: 'nature_stone', qty: 1 }] }
  },
  {
    id: 'side_02_lost_capsule', type: 'side', chapter: 'CHAPTER 1',
    name: 'The Collector\'s Request', description: 'Help a Collector find a rare monster near Greenmeadow Route.',
    steps: ['Capture a rare monster', 'Show it to the Collector'],
    reward: { money: 600 }
  },
  {
    id: 'hidden_01_old_key', type: 'hidden', chapter: 'CHAPTER 2',
    name: 'The Rusted Door', description: 'A rumor speaks of an old locked door deep in Mist Cave.',
    steps: ['Find the Old Key', 'Open the door in Mist Cave'],
    reward: { items: [{ id: 'ancient_shard', qty: 1 }] }
  },
  {
    id: 'main_04_eclipse_whisperwood', type: 'main', chapter: 'CHAPTER 2',
    name: 'Shadows in the Forest', description: 'Investigate Eclipse Order activity in Whisperwood Forest.',
    steps: ['Find the Eclipse grunts', 'Drive them off'],
    reward: { money: 1000 }
  }
];

export const QUESTS_BY_ID = Object.fromEntries(QUESTS.map(q => [q.id, q]));
