// High-level story structure. Used by QuestSystem/WorldScene to gate progression
// and by the README to document how to extend the world.
export const STORY = {
  title: 'MONSTERBOUND: Legends of Aurelia',
  themes: ['exploration', 'friendship', 'ambition', 'ancient civilization', 'monster origins', 'responsibility'],
  chapters: [
    { id: 'prologue', name: 'PROLOGUE', summary: 'You receive your first monster from Professor Aria in Starting Village and meet your rival, Corin.', implemented: true },
    { id: 'ch1', name: 'CHAPTER 1', summary: 'Travel Greenmeadow Route to Lumina City and earn the Flame Badge.', implemented: true },
    { id: 'ch2', name: 'CHAPTER 2', summary: 'Explore Whisperwood Forest, uncover early Eclipse Order activity, reach Riverdale Town.', implemented: true },
    { id: 'ch3', name: 'CHAPTER 3', summary: 'Delve into Mist Cave, find the Old Key, reach Ironhold City and earn the Nature Badge.', implemented: 'partial' },
    { id: 'ch4', name: 'CHAPTER 4', summary: 'Cross Mountain Pass, confront Corin again, reach Sunridge City and earn the Storm Badge.', implemented: false },
    { id: 'ch5', name: 'CHAPTER 5', summary: 'Cross the Golden Desert to Oasis Town and earn the Stone Badge.', implemented: false },
    { id: 'ch6', name: 'CHAPTER 6', summary: 'Explore the Ancient Ruins, Eclipse Order raids Ironhold Labs, story deepens.', implemented: false },
    { id: 'ch7', name: 'CHAPTER 7', summary: 'Reach Coastal City and the Island Region, earn the Shadow Badge.', implemented: false },
    { id: 'ch8', name: 'CHAPTER 8', summary: 'Cross the Volcanic Region to Skyridge City, earn the Metal Badge.', implemented: false },
    { id: 'finale', name: 'FINALE', summary: 'Enter the Final Region, earn the Mystic Badge, and stop the Eclipse Order at Eclipse Spire.', implemented: false },
    { id: 'postgame', name: 'POST-GAME', summary: 'Championship rematches, legendary encounters, and secret areas unlock.', implemented: false }
  ]
};
