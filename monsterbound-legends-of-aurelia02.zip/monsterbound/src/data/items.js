export const ITEM_CATEGORIES = ['Medicine', 'Capture Devices', 'Battle Items', 'Evolution Items', 'Key Items', 'Quest Items'];

export const ITEMS = [
  // Medicine
  { id: 'potion', name: 'Potion', category: 'Medicine', price: 200, sellPrice: 100, description: 'Restores 20 HP to a monster.', effect: { kind: 'heal', amount: 20 } },
  { id: 'super_potion', name: 'Super Potion', category: 'Medicine', price: 500, sellPrice: 250, description: 'Restores 50 HP to a monster.', effect: { kind: 'heal', amount: 50 } },
  { id: 'hyper_potion', name: 'Hyper Potion', category: 'Medicine', price: 1200, sellPrice: 600, description: 'Restores 120 HP to a monster.', effect: { kind: 'heal', amount: 120 } },
  { id: 'full_heal', name: 'Full Heal', category: 'Medicine', price: 400, sellPrice: 200, description: 'Cures all status conditions.', effect: { kind: 'cure_status' } },
  { id: 'revive', name: 'Revive', category: 'Medicine', price: 1500, sellPrice: 750, description: 'Revives a fainted monster with half HP.', effect: { kind: 'revive', percent: 50 } },
  { id: 'pp_restore', name: 'PP Restore', category: 'Medicine', price: 300, sellPrice: 150, description: 'Restores 10 PP to one move.', effect: { kind: 'restore_pp', amount: 10 } },

  // Capture Devices
  { id: 'basic_capsule', name: 'Basic Capsule', category: 'Capture Devices', price: 200, sellPrice: 100, description: 'A basic device for capturing wild monsters.', catchMultiplier: 1.0 },
  { id: 'advanced_capsule', name: 'Advanced Capsule', category: 'Capture Devices', price: 600, sellPrice: 300, description: 'A better capsule with a higher catch rate.', catchMultiplier: 1.5 },
  { id: 'elite_capsule', name: 'Elite Capsule', category: 'Capture Devices', price: 1200, sellPrice: 600, description: 'A high-performance capsule for tough monsters.', catchMultiplier: 2.0 },
  { id: 'master_capsule', name: 'Master Capsule', category: 'Capture Devices', price: 0, sellPrice: 0, description: 'Guarantees a capture. Extremely rare.', catchMultiplier: 255 },

  // Battle Items
  { id: 'x_attack', name: 'X-Attack', category: 'Battle Items', price: 500, sellPrice: 250, description: 'Raises Attack by one stage in battle.', effect: { kind: 'battle_buff', stat: 'attack', stages: 1 } },
  { id: 'x_defense', name: 'X-Defense', category: 'Battle Items', price: 500, sellPrice: 250, description: 'Raises Defense by one stage in battle.', effect: { kind: 'battle_buff', stat: 'defense', stages: 1 } },
  { id: 'x_speed', name: 'X-Speed', category: 'Battle Items', price: 500, sellPrice: 250, description: 'Raises Speed by one stage in battle.', effect: { kind: 'battle_buff', stat: 'speed', stages: 1 } },

  // Evolution Items - one elemental stone per type
  ...['Flame', 'Aqua', 'Nature', 'Storm', 'Stone', 'Frost', 'Shadow', 'Light', 'Metal', 'Wind', 'Mystic', 'Earth'].map(t => ({
    id: `${t.toLowerCase()}_stone`, name: `${t} Stone`, category: 'Evolution Items', price: 3000, sellPrice: 1500,
    description: `A radiant stone infused with ${t} energy. Some monsters evolve when exposed to it.`, evolutionType: t
  })),
  { id: 'friendship_charm', name: 'Friendship Charm', category: 'Evolution Items', price: 2000, sellPrice: 1000, description: 'Some monsters evolve through strong friendship while holding this.' },

  // Key Items
  { id: 'aurelia_map', name: 'Aurelia Map', category: 'Key Items', price: 0, sellPrice: 0, description: 'A map of the known regions of Aurelia.' },
  { id: 'old_key', name: 'Old Key', category: 'Key Items', price: 0, sellPrice: 0, description: 'An old rusted key. It might open something in Mist Cave.' },
  { id: 'gym_pass', name: 'Gym Challenge Pass', category: 'Key Items', price: 0, sellPrice: 0, description: 'Proof you may challenge Aurelia\'s Gym/Boss Leaders.' },
  { id: 'eclipse_badge_fake', name: 'Eclipse Insignia', category: 'Key Items', price: 0, sellPrice: 0, description: 'A stolen insignia of the Eclipse Order.' },

  // Quest Items
  { id: 'whisperwood_relic', name: 'Whisperwood Relic', category: 'Quest Items', price: 0, sellPrice: 0, description: 'A relic requested by an NPC in Whisperwood Forest.' },
  { id: 'ancient_shard', name: 'Ancient Shard', category: 'Quest Items', price: 0, sellPrice: 0, description: 'A shard of an ancient monster egg. It hums faintly.' }
];

export const ITEMS_BY_ID = Object.fromEntries(ITEMS.map(i => [i.id, i]));

export const AURELIA_BADGES = [
  { id: 'flame_badge', name: 'Flame Badge', leader: 'Flame Leader' },
  { id: 'tide_badge', name: 'Tide Badge', leader: 'Tide Leader' },
  { id: 'nature_badge', name: 'Nature Badge', leader: 'Nature Leader' },
  { id: 'storm_badge', name: 'Storm Badge', leader: 'Storm Leader' },
  { id: 'stone_badge', name: 'Stone Badge', leader: 'Stone Leader' },
  { id: 'shadow_badge', name: 'Shadow Badge', leader: 'Shadow Leader' },
  { id: 'metal_badge', name: 'Metal Badge', leader: 'Metal Leader' },
  { id: 'mystic_badge', name: 'Mystic Badge', leader: 'Mystic Leader' }
];
