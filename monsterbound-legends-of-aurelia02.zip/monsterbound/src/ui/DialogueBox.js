// A reusable dialogue box. Works inside any scene: pass the scene in and call
// showLines(['line one', 'line two'], onDone) or showChoice(prompt, options, onPick).
export default class DialogueBox {
  constructor(scene, opts = {}) {
    this.scene = scene;
    const width = scene.scale.width;
    const height = scene.scale.height;
    this.width = width;
    this.height = height;
    this.container = scene.add.container(0, 0).setDepth(1000).setVisible(false);

    const boxHeight = 110;
    const bg = scene.add.rectangle(width / 2, height - boxHeight / 2 - 10, width - 40, boxHeight, 0x0b0d17, 0.92)
      .setStrokeStyle(3, 0xffffff, 0.9);
    this.nameText = scene.add.text(40, height - boxHeight - 6, '', { fontFamily: 'monospace', fontSize: '16px', color: '#ffd76e', fontStyle: 'bold' });
    this.bodyText = scene.add.text(40, height - boxHeight + 8, '', { fontFamily: 'monospace', fontSize: '15px', color: '#ffffff', wordWrap: { width: width - 100 } });
    this.continueHint = scene.add.text(width - 70, height - 24, '▼ Z', { fontFamily: 'monospace', fontSize: '13px', color: '#aaaaaa' });
    this.container.add([bg, this.nameText, this.bodyText, this.continueHint]);

    this.choiceTexts = [];
    this.active = false;
    this.lines = [];
    this.lineIndex = 0;
    this.charIndex = 0;
    this.typing = false;
    this.onComplete = null;
    this.speedMs = 22;
  }

  get isActive() { return this.active; }

  showLines(lines, speakerName, onComplete) {
    this.lines = Array.isArray(lines) ? lines : [lines];
    this.lineIndex = 0;
    this.onComplete = onComplete;
    this.nameText.setText(speakerName || '');
    this.container.setVisible(true);
    this.active = true;
    this._typeCurrentLine();
  }

  _typeCurrentLine() {
    const full = this.lines[this.lineIndex] || '';
    this.charIndex = 0;
    this.typing = true;
    this.bodyText.setText('');
    this.continueHint.setVisible(false);
    if (this._timer) this._timer.remove();
    this._timer = this.scene.time.addEvent({
      delay: this.speedMs, loop: true,
      callback: () => {
        this.charIndex++;
        this.bodyText.setText(full.slice(0, this.charIndex));
        if (this.charIndex >= full.length) {
          this._timer.remove();
          this.typing = false;
          this.continueHint.setVisible(true);
        }
      }
    });
  }

  advance() {
    if (!this.active) return;
    if (this.typing) {
      // skip to full line
      this._timer.remove();
      this.bodyText.setText(this.lines[this.lineIndex]);
      this.typing = false;
      this.continueHint.setVisible(true);
      return;
    }
    this.lineIndex++;
    if (this.lineIndex >= this.lines.length) {
      this.close();
      if (this.onComplete) this.onComplete();
    } else {
      this._typeCurrentLine();
    }
  }

  showChoice(prompt, options, onPick) {
    this.close();
    this.container.setVisible(true);
    this.active = true;
    this.nameText.setText('');
    this.bodyText.setText(prompt);
    this.continueHint.setVisible(false);
    this.choiceTexts = options.map((opt, i) => {
      const t = this.scene.add.text(this.width - 220, this.height - 150 + i * 26, opt, {
        fontFamily: 'monospace', fontSize: '15px', color: '#ffffff', backgroundColor: '#00000088', padding: { x: 6, y: 2 }
      }).setDepth(1001).setInteractive({ useHandCursor: true });
      t.on('pointerdown', () => { this._resolveChoice(i, onPick); });
      this.container.add(t);
      return t;
    });
    this.choiceIndex = 0;
    this._highlightChoice();
    this._choiceCallback = onPick;
  }

  _highlightChoice() {
    this.choiceTexts.forEach((t, i) => t.setColor(i === this.choiceIndex ? '#ffd76e' : '#ffffff'));
  }

  moveChoice(dir) {
    if (!this.choiceTexts.length) return;
    this.choiceIndex = (this.choiceIndex + dir + this.choiceTexts.length) % this.choiceTexts.length;
    this._highlightChoice();
  }

  confirmChoice() {
    if (!this.choiceTexts.length) return;
    this._resolveChoice(this.choiceIndex, this._choiceCallback);
  }

  _resolveChoice(index, cb) {
    this.choiceTexts.forEach(t => t.destroy());
    this.choiceTexts = [];
    this.close();
    if (cb) cb(index);
  }

  close() {
    if (this._timer) this._timer.remove();
    this.active = false;
    this.typing = false;
    this.container.setVisible(false);
  }
}
