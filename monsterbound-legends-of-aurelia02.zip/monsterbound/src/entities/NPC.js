import { TILE_SIZE } from '../data/maps.js';

export default class NPC {
  constructor(scene, def, textureKey) {
    this.scene = scene;
    this.def = def;
    this.gridX = def.x;
    this.gridY = def.y;
    this.sprite = scene.add.sprite(def.x * TILE_SIZE + TILE_SIZE / 2, def.y * TILE_SIZE + TILE_SIZE / 2, textureKey);
    this.sprite.setDepth(5);
    this.talkedTo = false;
  }
}
