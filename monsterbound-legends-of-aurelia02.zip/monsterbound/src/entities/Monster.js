import { getSpecies } from '../data/monsters.js';
import { MOVES_BY_ID } from '../data/moves.js';

let uidCounter = 1;

export default class Monster {
  constructor(speciesId, level, opts = {}) {
    this.uid = opts.uid || `mon-${Date.now()}-${uidCounter++}`;
    this.speciesId = speciesId;
    this.level = level;
    this.xp = opts.xp || 0;
    this.nickname = opts.nickname || null;
    this.status = opts.status || null; // burn, freeze, poison, shock, sleep, confusion, slow
    this.statStages = opts.statStages || { attack: 0, defense: 0, speed: 0, special: 0 };
    this.friendship = opts.friendship ?? 50;
    this.moves = opts.moves || this._defaultMovesForLevel();
    this.currentHp = opts.currentHp ?? this.maxHp;
    this.caughtWith = opts.caughtWith || null;
    this.protectFlag = false;
  }

  get species() { return getSpecies(this.speciesId); }

  get name() { return this.nickname || this.species.name; }

  _statAtLevel(base) {
    // simple RPG growth curve
    return Math.floor(((base * 2) * this.level) / 100 + this.level + 5);
  }

  get maxHp() {
    const base = this.species.base.hp;
    return Math.floor(((base * 2) * this.level) / 100 + this.level + 10);
  }
  get attack() { return this._statAtLevel(this.species.base.attack); }
  get defense() { return this._statAtLevel(this.species.base.defense); }
  get speed() { return this._statAtLevel(this.species.base.speed); }
  get specialAttack() { return this._statAtLevel(this.species.base.specialAttack); }
  get specialDefense() { return this._statAtLevel(this.species.base.specialDefense); }

  statWithStage(baseValue, stat) {
    const stage = this.statStages[stat] || 0;
    const mult = stage >= 0 ? (2 + stage) / 2 : 2 / (2 - stage);
    return Math.max(1, Math.floor(baseValue * mult));
  }

  get isFainted() { return this.currentHp <= 0; }

  _defaultMovesForLevel() {
    const learnset = this.species.learnset.filter(l => l.level <= this.level);
    const chosen = learnset.slice(-4).map(l => l.moveId);
    return chosen.map(id => ({ moveId: id, pp: MOVES_BY_ID[id].maxPp }));
  }

  learnableAtLevel(level) {
    return this.species.learnset.filter(l => l.level === level);
  }

  xpToNextLevel() {
    const rate = this.species.xpToLevel || 1.0;
    return Math.floor(rate * Math.pow(this.level + 1, 3) / 4);
  }

  gainXp(amount) {
    const events = [];
    this.xp += amount;
    while (this.xp >= this.xpToNextLevel() && this.level < 100) {
      this.xp -= this.xpToNextLevel();
      this.level++;
      events.push({ type: 'levelup', level: this.level });
      const newMoves = this.learnableAtLevel(this.level);
      for (const nm of newMoves) {
        events.push({ type: 'learnmove', moveId: nm.moveId });
        if (this.moves.length < 4) {
          this.moves.push({ moveId: nm.moveId, pp: MOVES_BY_ID[nm.moveId].maxPp });
        } else {
          events.push({ type: 'move_queue_full', moveId: nm.moveId });
        }
      }
      if (this.species.evolvesAtLevel && this.level >= this.species.evolvesAtLevel && this.species.evolvesTo) {
        events.push({ type: 'evolve_ready', toId: this.species.evolvesTo });
      }
    }
    return events;
  }

  heal(amount) {
    this.currentHp = Math.min(this.maxHp, this.currentHp + amount);
  }

  fullHeal() {
    this.currentHp = this.maxHp;
    this.status = null;
    this.moves.forEach(m => { m.pp = MOVES_BY_ID[m.moveId].maxPp; });
  }

  serialize() {
    return {
      uid: this.uid, speciesId: this.speciesId, level: this.level, xp: this.xp,
      nickname: this.nickname, status: this.status, statStages: this.statStages,
      friendship: this.friendship, moves: this.moves, currentHp: this.currentHp,
      caughtWith: this.caughtWith
    };
  }

  static deserialize(data) {
    return new Monster(data.speciesId, data.level, data);
  }
}
