import { TILE_SIZE } from '../data/maps.js';

export default class Player {
  constructor(scene, gridX, gridY, textureKey) {
    this.scene = scene;
    this.gridX = gridX;
    this.gridY = gridY;
    this.facing = 'down';
    this.moving = false;
    this.sprite = scene.add.sprite(gridX * TILE_SIZE + TILE_SIZE / 2, gridY * TILE_SIZE + TILE_SIZE / 2, textureKey);
    this.sprite.setDepth(10);
    this.moveDuration = 160;
  }

  get pixelX() { return this.sprite.x; }
  get pixelY() { return this.sprite.y; }

  tryMove(dx, dy, running, map, onArrive) {
    if (this.moving) return false;
    if (dx !== 0) this.facing = dx > 0 ? 'right' : 'left';
    if (dy !== 0) this.facing = dy > 0 ? 'down' : 'up';

    const targetX = this.gridX + dx;
    const targetY = this.gridY + dy;
    if (!map.isWalkable(targetX, targetY)) return false;

    this.moving = true;
    const duration = running ? this.moveDuration * 0.55 : this.moveDuration;
    this.gridX = targetX;
    this.gridY = targetY;
    this.scene.tweens.add({
      targets: this.sprite,
      x: targetX * TILE_SIZE + TILE_SIZE / 2,
      y: targetY * TILE_SIZE + TILE_SIZE / 2,
      duration,
      onComplete: () => {
        this.moving = false;
        if (onArrive) onArrive(targetX, targetY);
      }
    });
    return true;
  }

  facingTile() {
    const deltas = { up: [0, -1], down: [0, 1], left: [-1, 0], right: [1, 0] };
    const [dx, dy] = deltas[this.facing];
    return { x: this.gridX + dx, y: this.gridY + dy };
  }
}
